"""Neural Information Preservation Index (NIPI).

NIPI answers: "after denoising, how much of the neural information that was in the clean EEG
is still there?"  It is a reference-based index in [0, 1] (1 = nothing lost) built from SIX
components that mirror the problem statement:

    S  spectral consistency        - log-PSD distortion in dB                      -> exp(-dB / tol_S)
    P  phase-locking preservation  - PLV between clean & denoised band phase       -> mean PLV over 5 bands
    C  connectivity retention      - inter-electrode PLV matrices (5 bands)        -> 0.5*corr+ + 0.5*(1-MAE)
    E  ERP morphology similarity   - class-averaged ERP: shape, amplitude, latency -> mean of 3 terms
    H  entropy preservation        - permutation + spectral entropy                -> exp(-|dH| / tol_H)
    D  task-discriminability       - cross-validated AUC retention                 -> (AUC_den-.5)/(AUC_clean-.5)

NIPI = prod_k  c_k ^ w_k      (weighted GEOMETRIC mean, sum w_k = 1)

Geometric (non-compensatory) aggregation is deliberate: a denoiser that destroys ONE kind of
information (e.g. phase) must not be able to hide it behind good scores on the others.
Components that cannot be computed (no labels / no event markers) are dropped and the
remaining weights are re-normalised.

Properties (verified in tests/test_nipi.py): NIPI(x, x) = 1;  0 <= NIPI <= 1;  decreases
monotonically when the denoised signal is progressively corrupted.
"""
from dataclasses import dataclass, field
import numpy as np
from scipy import signal
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_auc_score

from .config import BANDS
from .dsp import bandpass, welch_psd

EPS = 1e-12


@dataclass
class NIPIConfig:
    weights: dict = field(default_factory=lambda: dict(S=0.15, P=0.20, C=0.20, E=0.15, H=0.10, D=0.20))
    tol_S_db: float = 3.0       # 3 dB average spectral distortion  -> S = e^-1
    tol_H: float = 0.05         # 0.05 (normalised) entropy change   -> H = e^-1
    perm_order: int = 4
    perm_delay: int = 2
    edge_trim_s: float = 0.25   # drop Hilbert edge effects
    fmin: float = 1.0
    fmax: float = 45.0
    erp_window: tuple = (-0.2, 1.2)   # seconds relative to cue
    lat_tol_s: float = 0.10     # 100 ms latency error -> 0 for the latency term
    mu_beta_bands: tuple = ((8.0, 13.0), (13.0, 30.0))   # features for discriminability
    cv_folds: int = 5
    seed: int = 0


# ----------------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------------
def _unit_phasor(x, fs, lo, hi, trim):
    xb = bandpass(x, lo, hi, fs)
    z = signal.hilbert(xb, axis=-1)
    u = z / (np.abs(z) + EPS)
    if trim > 0:
        u = u[..., trim:-trim]
    return u.astype(np.complex64)


def _plv_matrix(u):
    """u: (N,C,T) unit phasors -> (N,C,C) phase-locking value between all electrode pairs."""
    T = u.shape[-1]
    M = np.einsum('nct,ndt->ncd', u, np.conj(u)) / T
    return np.abs(M)


def _perm_entropy(x, order, delay):
    """Normalised permutation entropy per (epoch, channel). x: (N,C,T)."""
    N, C, T = x.shape
    n = T - (order - 1) * delay
    cols = np.stack([x[..., i * delay:i * delay + n] for i in range(order)], axis=-1)  # (N,C,n,order)
    ranks = np.argsort(np.argsort(cols, axis=-1), axis=-1)
    base = order ** np.arange(order)
    code = (ranks * base).sum(-1).reshape(N * C, n)
    nsym = order ** order
    H = np.empty(N * C)
    for i in range(N * C):
        c = np.bincount(code[i], minlength=nsym).astype(float)
        p = c[c > 0] / c.sum()
        H[i] = -(p * np.log(p)).sum()
    nperm = float(np.prod(np.arange(1, order + 1)))
    return (H / np.log(nperm)).reshape(N, C)


def _spec_entropy(psd):
    p = psd / (psd.sum(-1, keepdims=True) + EPS)
    return -(p * np.log(p + EPS)).sum(-1) / np.log(psd.shape[-1])


def _erp(x, y, fs, cue, win):
    i0 = max(0, int(round((cue + win[0]) * fs)))
    i1 = min(x.shape[-1], int(round((cue + win[1]) * fs)))
    seg = x[..., i0:i1]
    base_n = max(1, int(round(min(0.2, cue) * fs)))
    b0 = max(0, int(round(cue * fs)) - base_n)
    base = x[..., b0:int(round(cue * fs))].mean(-1, keepdims=True)
    seg = seg - base
    return np.stack([seg[y == k].mean(0) for k in np.unique(y)], 0), i0   # (K,C,L)


def _disc_features(x, fs, bands):
    f = []
    for lo, hi in bands:
        xb = bandpass(x, lo, hi, fs)
        f.append(np.log(xb.var(-1) + EPS))
    return np.concatenate(f, axis=1)


def _cv_auc(F, y, folds, seed):
    skf = StratifiedKFold(folds, shuffle=True, random_state=seed)
    clf = LinearDiscriminantAnalysis(solver='lsqr', shrinkage='auto')
    s = cross_val_predict(clf, F, y, cv=skf, method='decision_function')
    return roc_auc_score(y, s)


# ----------------------------------------------------------------------------------
class NIPIReference:
    """Pre-computes everything that depends only on the CLEAN reference so that scoring many
    denoised candidates (hyper-parameter search, benchmarks) is fast."""

    def __init__(self, clean, fs, y=None, cue_time=None, cfg=None):
        self.cfg = cfg or NIPIConfig()
        self.fs = fs
        self.clean = clean = np.asarray(clean, float)
        self.y = None if y is None else np.asarray(y)
        self.cue = cue_time
        c = self.cfg
        self.trim = int(c.edge_trim_s * fs)
        f, p = welch_psd(clean, fs)
        self.sel = (f >= c.fmin) & (f <= c.fmax)
        self.f = f[self.sel]
        self.psd = p[..., self.sel]
        self.u = {b: _unit_phasor(clean, fs, lo, hi, self.trim) for b, (lo, hi) in BANDS.items()}
        self.plv = {b: _plv_matrix(self.u[b]) for b in BANDS}
        self.pe = _perm_entropy(clean, c.perm_order, c.perm_delay)
        self.se = _spec_entropy(self.psd)
        self.has_erp = self.y is not None and cue_time is not None
        if self.has_erp:
            self.erp, self.erp_i0 = _erp(clean, self.y, fs, cue_time, c.erp_window)
        self.has_disc = self.y is not None and len(np.unique(self.y)) > 1 and min(np.bincount(self.y)) >= c.cv_folds
        if self.has_disc:
            self.Fc = _disc_features(clean, fs, c.mu_beta_bands)
            self.auc_clean = _cv_auc(self.Fc, self.y, c.cv_folds, c.seed)
            if self.auc_clean < 0.6:        # nothing task-related to preserve -> metric undefined
                self.has_disc = False

    # ------------------------------------------------------------------
    def components(self, den):
        c, fs = self.cfg, self.fs
        den = np.asarray(den, float)
        out = {}
        # S ---------------------------------------------------------------
        f, p = welch_psd(den, fs)
        p = p[..., self.sel]
        d_db = np.abs(10 * np.log10((p + EPS) / (self.psd + EPS))).mean()
        out['S'] = float(np.exp(-d_db / c.tol_S_db))
        # P and C ---------------------------------------------------------
        plv_pe, c_terms = [], []
        for b, (lo, hi) in BANDS.items():
            u = _unit_phasor(den, fs, lo, hi, self.trim)
            plv_pe.append(np.abs(np.mean(u * np.conj(self.u[b]), axis=-1)).mean())
            m = _plv_matrix(u)
            iu = np.triu_indices(m.shape[1], 1)
            a, bb = m[:, iu[0], iu[1]], self.plv[b][:, iu[0], iu[1]]
            mae = np.abs(a - bb).mean()
            rho = np.mean([np.corrcoef(a[i], bb[i])[0, 1] for i in range(a.shape[0])])
            rho = 0.0 if not np.isfinite(rho) else max(rho, 0.0)
            c_terms.append(0.5 * rho + 0.5 * (1 - mae))
        out['P'] = float(np.mean(plv_pe))
        out['C'] = float(np.clip(np.mean(c_terms), 0, 1))
        # H ---------------------------------------------------------------
        pe = _perm_entropy(den, c.perm_order, c.perm_delay)
        se = _spec_entropy(p)
        dH = 0.5 * (np.abs(pe - self.pe).mean() + np.abs(se - self.se).mean())
        out['H'] = float(np.exp(-dH / c.tol_H))
        # E ---------------------------------------------------------------
        if self.has_erp:
            erp, _ = _erp(den, self.y, fs, self.cue, c.erp_window)
            e_terms = []
            for k in range(erp.shape[0]):
                r, rr = erp[k], self.erp[k]
                num = (r * rr).sum(1)
                den_ = np.sqrt((r ** 2).sum(1) * (rr ** 2).sum(1)) + EPS
                w = (rr ** 2).sum(1)
                w = w / w.sum()
                corr = max(float((w * num / den_).sum()), 0.0)
                ra = np.sqrt((r ** 2).sum()) / (np.sqrt((rr ** 2).sum()) + EPS)
                amp = max(0.0, 1 - abs(ra - 1))
                ch = int(np.argmax(np.abs(rr).max(1)))
                lat = abs(int(np.argmax(np.abs(r[ch]))) - int(np.argmax(np.abs(rr[ch])))) / fs
                lat_t = max(0.0, 1 - lat / c.lat_tol_s)
                e_terms.append((corr + amp + lat_t) / 3.0)
            out['E'] = float(np.mean(e_terms))
        # D ---------------------------------------------------------------
        if self.has_disc:
            F = _disc_features(den, fs, c.mu_beta_bands)
            auc = _cv_auc(F, self.y, c.cv_folds, c.seed)
            out['D'] = float(np.clip((auc - 0.5) / (self.auc_clean - 0.5), 0, 1))
            out['_auc_den'] = float(auc)
            out['_auc_clean'] = float(self.auc_clean)
        return out

    def score(self, den):
        comp = self.components(den)
        w = {k: v for k, v in self.cfg.weights.items() if k in comp}
        tot = sum(w.values())
        logn = sum((w[k] / tot) * np.log(max(comp[k], 1e-6)) for k in w)
        res = {k: v for k, v in comp.items()}
        res['NIPI'] = float(np.exp(logn))
        res['_components_used'] = ''.join(sorted(w))
        return res


def nipi(clean, denoised, fs, y=None, cue_time=None, cfg=None):
    """One-shot convenience wrapper."""
    return NIPIReference(clean, fs, y, cue_time, cfg).score(denoised)


# ----------------------------------------------------------------------------------
# Complementary information-theoretic diagnostic (Approach 1, 'information-theoretic denoising')
# ----------------------------------------------------------------------------------
def gaussian_mi_coefficient(clean, den, fs, band=(1.0, 45.0)):
    """Linfoot information coefficient  r_I = sqrt(1 - exp(-2 I(X;Xhat)/C))  in [0,1], where
    I is the Gaussian mutual information between the clean and denoised multichannel signals:
        I = 0.5 [ logdet S_x + logdet S_xhat - logdet S_joint ]
    r_I = 1: denoised output carries all the information of the clean EEG."""
    x = bandpass(clean, *band, fs)
    z = bandpass(den, *band, fs)
    C = x.shape[1]
    X = x.transpose(1, 0, 2).reshape(C, -1)
    Z = z.transpose(1, 0, 2).reshape(C, -1)
    J = np.vstack([X, Z])
    reg = 1e-6
    def ld(M):
        M = np.cov(M) + reg * np.eye(M.shape[0]) * np.trace(np.cov(M)) / M.shape[0]
        return np.linalg.slogdet(M)[1]
    I = 0.5 * (ld(X) + ld(Z) - ld(J))
    return float(np.sqrt(max(0.0, 1 - np.exp(-2 * I / C))))
