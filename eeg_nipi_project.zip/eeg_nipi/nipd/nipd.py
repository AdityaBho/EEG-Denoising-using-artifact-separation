"""NIPD - Neural-Information-Preserving Denoiser with Adaptive Artifact Separation.

Three-stage framework (matches the Review-1 methodology slide):

 STAGE 1  Artifact characterisation  - each artifact class is modelled by its OWN signature
     line noise : narrow-band, stationary      -> adaptive sinusoid regression (frequency refined
                                                  to +-0.5 Hz; neighbouring bins untouched, unlike a notch)
     EOG        : low-frequency, frontal, coherent across electrodes -> robust frontal reference
                  (median of 5 frontal sites, immune to single-electrode pops) -> sparse Gaussian/
                  plateau atoms -> propagation vector estimated with a GRAPH-Laplacian prior
     motion     : abrupt, single-electrode, then exponential recovery -> sparse 'pop' atoms
     EMG        : broadband, bursty, focal, strong ABOVE the neural band -> in-band EMG power is
                  predicted from the out-of-band (>50 Hz) reference using a learned spectral
                  signature rho(f), then removed by spectral subtraction

 STAGE 2  Neural-information preservation - every removal is *conservative by construction*
     * only the part of the signal that an artifact model explains is subtracted (never a band, never a
       whole component), with per-class strength g_k in [0,1]
     * residual neural spectrum is protected by a spectral floor (beta) in the EMG step
     * the strengths / thresholds theta = (g_k, k_eog, k_mot, alpha, beta, mu) are tuned by the NIPI
       FEEDBACK LOOP (tune.py): minimise  RER(theta) + lambda * (1 - NIPI(theta))

 STAGE 3  Physiological validation - NIPI (nipi.py) + task-discriminability + connectivity, see evaluate.py
"""
from dataclasses import dataclass, asdict
import numpy as np
from scipy import signal

from .config import CH_NAMES
from .dsp import lowpass, bandpass
from .graph import electrode_graph
from .sparse import sparse_transient_fit, gauss_atoms, plateau_atoms, pop_atoms
from .synthetic import sim_emg, scale_to_snr

IDX = {c: i for i, c in enumerate(CH_NAMES)}
FRONTAL5 = [IDX[c] for c in ('Fp1', 'Fp2', 'F3', 'Fz', 'F4')]
LAT = (IDX['F7'], IDX['F8'])


@dataclass
class NIPDParams:
    g_line: float = 1.0
    g_eog: float = 1.0
    g_motion: float = 1.0
    g_emg: float = 1.0
    eog_k: float = 4.0        # robust z-threshold for blink / saccade atoms
    motion_k: float = 6.0     # robust z-threshold for pop atoms
    emg_alpha: float = 1.0    # over-subtraction of the predicted EMG power
    emg_beta: float = 0.10    # spectral floor = protected fraction of observed power
    graph_mu: float = 1.0     # graph-Laplacian smoothness weight on EOG propagation vectors
    line_ratio: float = 4.0   # peak-to-background ratio needed to declare line noise present

    def as_dict(self):
        return asdict(self)


class NIPD:
    name = 'NIPD (proposed)'

    def __init__(self, fs, line_freq=50.0, params=None):
        self.fs = fs
        self.line = line_freq
        self.p = params or NIPDParams()
        self.A, self.L, _, _ = electrode_graph()
        # STFT geometry (0.25 s window, 75 % overlap)
        self.nseg = int(round(0.25 * fs / 2) * 2)
        self.nover = self.nseg - max(1, self.nseg // 8)
        self.rho = None            # learned EMG spectral signature rho(f)
        self.hf_band = self._hf_band()
        self.hf_floor = None

    # ------------------------------------------------------------------ utils
    def _hf_band(self):
        return (50.0 if self.fs / 2 > 70 else 45.0, 0.92 * self.fs / 2)

    def _stft(self, X):
        f, t, S = signal.stft(X, fs=self.fs, window='hann', nperseg=self.nseg, noverlap=self.nover,
                              boundary='zeros', padded=True, axis=-1)
        return f, S

    def _istft(self, S, T):
        _, x = signal.istft(S, fs=self.fs, window='hann', nperseg=self.nseg, noverlap=self.nover,
                            boundary=True, input_onesided=True, time_axis=-1, freq_axis=-2)
        return x[..., :T]

    def _hf_mask(self, f):
        lo, hi = self.hf_band
        m = (f >= lo) & (f <= hi)
        for h in (1, 2, 3):
            m &= ~(np.abs(f - h * self.line) < 3.0)
        return m

    # ------------------------------------------------------------------ fit (learn EMG signature)
    def fit(self, clean_train, seed=0, snrs=(-5.0, 0.0, 5.0)):
        """Learn rho(f): ratio between the EMG power that appears in each frequency bin and the
        out-of-band (reference) EMG power, by least squares over simulated EMG-only bursts on the
        training EEG.  (With real EMG templates, e.g. EEGdenoiseNet, call fit_from_pairs instead.)"""
        rng = np.random.default_rng(seed)
        N, C, T = clean_train.shape
        emg0 = sim_emg(N, T, self.fs, rng)
        pairs = []
        for s in snrs:
            a = scale_to_snr(clean_train, emg0, s)
            pairs.append((clean_train + a, a))
        self.fit_from_pairs(pairs)
        return self

    def fit_from_pairs(self, pairs):
        """pairs: list of (contaminated, artifact_only) EMG examples."""
        num, den = 0.0, 0.0
        floors = []
        for cont, art in pairs:
            f, Sc = self._stft(cont)
            _, Sa = self._stft(art)
            hfm = self._hf_mask(f)
            Phf = (np.abs(Sc[:, :, hfm]) ** 2).mean(2)                    # (N,C,Tf)
            fl = np.percentile(Phf, 10, axis=(0, 2))                      # (C,)
            floors.append(fl)
            E = np.maximum(Phf - fl[None, :, None], 0.0)
            Pa = np.abs(Sa) ** 2                                          # EMG-only power per bin
            num = num + (Pa * E[:, :, None, :]).sum((0, 1, 3))
            den = den + (E ** 2).sum() + 1e-12
        self.rho = np.maximum(num / den, 0.0)                              # (F,)
        self.rho_f = f
        self.hf_floor = np.median(np.stack(floors), 0)

    # ------------------------------------------------------------------ stage 1 modules
    def estimate_line(self, X):
        N, C, T = X.shape
        t = np.arange(T) / self.fs
        out = np.zeros_like(X)
        f0s = self.line + np.linspace(-0.5, 0.5, 21)
        spec = np.abs(np.fft.rfft(X.mean(1), axis=-1)) ** 2
        fr = np.fft.rfftfreq(T, 1 / self.fs)
        for i in range(N):
            pk = spec[i][(np.abs(fr - self.line) < 0.6)].max()
            bg = np.median(spec[i][((np.abs(fr - self.line) > 2.0) & (np.abs(fr - self.line) < 9.0))]) + 1e-12
            if pk / bg < self.p.line_ratio:
                continue
            best, bestE = None, -1
            for f0 in f0s:
                cols = [np.sin(2 * np.pi * f0 * t), np.cos(2 * np.pi * f0 * t)]
                if 2 * f0 < 0.95 * self.fs / 2:
                    cols += [np.sin(4 * np.pi * f0 * t), np.cos(4 * np.pi * f0 * t)]
                D = np.stack(cols, 1)
                beta, *_ = np.linalg.lstsq(D, X[i].T, rcond=None)
                fit = (D @ beta).T
                e = (fit ** 2).sum()
                if e > bestE:
                    best, bestE = fit, e
            out[i] = best
        return out

    def _ref_lp(self, X, chans):
        return lowpass(np.median(X[:, chans], axis=1), 12.0, self.fs)

    def estimate_eog(self, X):
        """Returns the estimated EOG contribution (N,C,T)."""
        N, C, T = X.shape
        fs = self.fs
        Xlp = lowpass(X, 12.0, fs)
        refs, atoms = [], []
        # vertical (blink) reference : robust median of 5 frontal sites
        refs.append(self._ref_lp(X, FRONTAL5))
        atoms.append(gauss_atoms(fs) + plateau_atoms(fs))
        # horizontal (saccade) reference : F8 - F7
        refs.append(lowpass(X[:, LAT[1]] - X[:, LAT[0]], 12.0, fs))
        atoms.append(plateau_atoms(fs) + gauss_atoms(fs))
        out = np.zeros_like(X)
        resid = Xlp.copy()
        for ref, at in zip(refs, atoms):
            s_hat = sparse_transient_fit(ref, at, k=self.p.eog_k, max_atoms=6)      # (N,T)
            if not np.any(s_hat):
                continue
            b = self._propagation(resid, s_hat)
            part = b[None, :, None] * s_hat[:, None, :]
            out += part
            resid = resid - part
        return out

    def _propagation(self, Xlp, s):
        """Pooled, robust (IRLS), graph-regularised LS estimate of the scalp propagation vector b:
              min_b  sum_t w_t || x_c(t) - b_c s(t) ||^2  +  mu * b^T L b       (b smooth on the electrode graph)"""
        C = Xlp.shape[1]
        w = np.ones_like(Xlp)
        b = np.zeros(C)
        ss = (s ** 2).sum()
        for _ in range(3):
            num = (w * Xlp * s[:, None, :]).sum((0, 2))
            den = (w * (s[:, None, :] ** 2)).sum((0, 2))
            M = np.diag(den) + self.p.graph_mu * ss * 1e-3 * self.L * 0 + self.p.graph_mu * (den.mean()) * 0.05 * self.L
            b = np.linalg.solve(M + 1e-9 * np.eye(C), num)
            r = Xlp - b[None, :, None] * s[:, None, :]
            sig = np.median(np.abs(r), axis=(0, 2)) / 0.6745 + 1e-9
            u = np.abs(r) / (2.5 * sig[None, :, None])
            w = np.where(u <= 1, 1.0, 1.0 / u)
        return b

    def estimate_motion(self, X):
        N, C, T = X.shape
        Y = lowpass(X, 25.0, self.fs).reshape(N * C, T)
        fit = sparse_transient_fit(Y, pop_atoms(self.fs), k=self.p.motion_k, max_atoms=4)
        return fit.reshape(N, C, T)

    def estimate_emg(self, X):
        N, C, T = X.shape
        if self.rho is None:
            raise RuntimeError('call fit() first (learns the EMG spectral signature)')
        f, S = self._stft(X)
        P = np.abs(S) ** 2
        hfm = self._hf_mask(f)
        Phf = P[:, :, hfm].mean(2)                                     # (N,C,Tf)
        fl = self.hf_floor if self.hf_floor is not None else np.percentile(Phf, 10, axis=(0, 2))
        E = np.maximum(Phf - fl[None, :, None], 0.0)
        Pemg = self.p.emg_alpha * self.rho[None, None, :, None] * E[:, :, None, :]
        gain = np.sqrt(np.maximum(1.0 - Pemg / (P + 1e-12), self.p.emg_beta))
        gain[:, :, hfm, :] = 1.0                                       # never touch the reference band here
        Sc = S * gain
        clean = self._istft(Sc, T)
        return X - clean                                               # estimated EMG contribution

    # ------------------------------------------------------------------ full pipeline
    def denoise(self, X, return_parts=False):
        p = self.p
        X = np.asarray(X, float)
        parts = {}
        cur = X
        parts['line'] = self.estimate_line(cur) * p.g_line
        cur = cur - parts['line']
        parts['eog'] = self.estimate_eog(cur) * p.g_eog
        cur = cur - parts['eog']
        parts['motion'] = self.estimate_motion(cur) * p.g_motion
        cur = cur - parts['motion']
        parts['emg'] = self.estimate_emg(cur) * p.g_emg
        cur = cur - parts['emg']
        return (cur, parts) if return_parts else cur
