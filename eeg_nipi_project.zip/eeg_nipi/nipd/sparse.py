"""Sparse transient decomposition (matching pursuit) used by Stage 1 to isolate artifact
transients (blinks, saccades, electrode pops) from oscillatory neural activity.

Principle (problem statement, Stage 1: "sparse signal representations help separate transient
artifact components from underlying neural activity"):
  an artifact transient is well described by ONE short atom with a large, isolated coefficient,
  whereas neural rhythms spread their energy over many small coefficients and never produce an
  isolated large one.  Matching pursuit therefore removes only what a handful of atoms explain.
Detection uses a ROBUST z-score of the coefficient field (MAD), so the threshold adapts to the
colour of the background activity.
"""
import numpy as np


def _unit(a):
    return a / (np.linalg.norm(a) + 1e-12)


def gauss_atoms(fs, sigmas=(0.04, 0.07, 0.10, 0.15)):
    out = []
    for s in sigmas:
        L = int(6 * s * fs) | 1
        n = np.arange(L) - L // 2
        out.append(_unit(np.exp(-0.5 * (n / (s * fs)) ** 2)))
    return out


def plateau_atoms(fs, dwell=(0.3, 0.5, 0.8), taper=0.06):
    out = []
    for d in dwell:
        L = int(d * fs)
        w = np.ones(L)
        k = int(taper * fs)
        ramp = 0.5 - 0.5 * np.cos(np.pi * np.arange(k) / k)
        w[:k], w[-k:] = ramp, ramp[::-1]
        out.append(_unit(w))
    return out


def pop_atoms(fs, taus=(0.03, 0.06, 0.12, 0.25)):
    """Abrupt onset + exponential recovery (electrode pop / cable movement)."""
    out = []
    for tau in taus:
        L = int(4 * tau * fs)
        out.append(_unit(np.exp(-np.arange(L) / (tau * fs))))
    return out


def sparse_transient_fit(Y, atoms, k=5.0, max_atoms=6):
    """Greedy matching pursuit.  Y: (B,T).  Returns fit (B,T) = sum of accepted atoms."""
    B, T = Y.shape
    nfft = 2 * T
    AF = [np.fft.rfft(a, nfft) for a in atoms]
    R = Y.astype(float).copy()
    fit = np.zeros_like(R)
    active = np.ones(B, bool)
    S = len(atoms)
    for _ in range(max_atoms):
        idx = np.where(active)[0]
        if idx.size == 0:
            break
        Yf = np.fft.rfft(R[idx], nfft, axis=-1)
        Cs = np.zeros((idx.size, S, T))
        for s, (a, af) in enumerate(zip(atoms, AF)):
            c = np.fft.irfft(Yf * np.conj(af)[None], nfft, axis=-1)[:, :T]
            c[:, max(T - len(a) + 1, 0):] = 0.0          # only full atoms inside the window
            Cs[:, s] = c
        med = np.median(Cs, axis=-1, keepdims=True)
        mad = np.median(np.abs(Cs - med), axis=-1, keepdims=True) * 1.4826 + 1e-9
        Z = np.abs(Cs) / mad
        flat = Z.reshape(idx.size, -1)
        am = flat.argmax(1)
        zmax = flat[np.arange(idx.size), am]
        ok = zmax >= k
        for r in np.where(ok)[0]:
            s, t0 = divmod(int(am[r]), T)
            a = atoms[s]
            amp = Cs[r, s, t0]
            R[idx[r], t0:t0 + len(a)] -= amp * a
            fit[idx[r], t0:t0 + len(a)] += amp * a
        active[idx[~ok]] = False
    return fit
