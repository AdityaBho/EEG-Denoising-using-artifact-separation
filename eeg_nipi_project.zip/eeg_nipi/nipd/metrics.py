"""Conventional reconstruction metrics (what the literature reports) - used as comparison to NIPI."""
import numpy as np


def rmse(clean, den):
    return float(np.sqrt(np.mean((clean - den) ** 2)))


def rrmse(clean, den):
    """Relative RMSE (EEGdenoiseNet): RMS(error)/RMS(clean)."""
    return float(np.sqrt(np.mean((clean - den) ** 2)) / (np.sqrt(np.mean(clean ** 2)) + 1e-12))


def cc(clean, den):
    """Mean Pearson correlation per (epoch, channel)."""
    a = clean - clean.mean(-1, keepdims=True)
    b = den - den.mean(-1, keepdims=True)
    num = (a * b).sum(-1)
    d = np.sqrt((a ** 2).sum(-1) * (b ** 2).sum(-1)) + 1e-12
    return float(np.mean(num / d))


def rer(clean, contaminated, den):
    """Residual Error Ratio = ||den-clean||^2 / ||contaminated-clean||^2.
    1 = nothing removed, 0 = perfect, >1 = made things worse.  This is the 'minimise artifact
    energy' term of the conventional objective."""
    return float(((den - clean) ** 2).sum() / (((contaminated - clean) ** 2).sum() + 1e-12))


def snr_db(clean, den):
    return float(10 * np.log10((clean ** 2).sum() / (((den - clean) ** 2).sum() + 1e-12)))
