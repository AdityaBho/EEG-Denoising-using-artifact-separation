"""Benchmark harness: semi-synthetic evaluation (clean EEG + known artifact at known SNR).

Every method sees the SAME contaminated data; every output goes through the SAME 1-45 Hz
post-filter; every score is computed against eval_filter(clean).  Baselines get the standard
Review-1 pre-processing (notch at the mains frequency); NIPD does its own adaptive line removal.
"""
import time
import numpy as np
import pandas as pd
from scipy import signal

from .dsp import eval_filter
from .metrics import rrmse, rmse, cc, rer, snr_db
from .nipi import NIPIReference, NIPIConfig, gaussian_mi_coefficient
from .synthetic import simulate_artifacts
from .baselines import FilterOnly, ICADenoiser, NLMSDenoiser, WaveletDenoiser


def notch(x, fs, f0, Q=30.0):
    for h in (1, 2):
        f = h * f0
        if f < 0.95 * fs / 2:
            b, a = signal.iirnotch(f, Q, fs=fs)
            x = signal.filtfilt(b, a, x, axis=-1)
    return x


class Notched:
    """Standard Review-1 pre-processing (mains notch) followed by a baseline method."""
    def __init__(self, method, fs, line_freq):
        self.m, self.fs, self.line = method, fs, line_freq
        self.name = method.name

    def denoise(self, X):
        return self.m.denoise(notch(X, self.fs, self.line))


def tune_baselines(clean, fs, line_freq, seed=100, kinds=('eog', 'emg', 'motion', 'mixed'), snr=0.0):
    """Give every baseline its BEST hyper-parameter on a held-out tuning split (fair comparison)."""
    ref = eval_filter(clean, fs)
    conds = [simulate_artifacts(clean, fs, k, snr, seed=seed + i, line_freq=line_freq)[0] for i, k in enumerate(kinds)]

    def score(method):
        return np.mean([rrmse(ref, eval_filter(method.denoise(c), fs)) for c in conds])

    grid = [(m, k) for m in ('level', 'visu') for k in (0.5, 1, 2, 4, 8, 16, 40)]
    best_w = min(grid, key=lambda mk: score(Notched(WaveletDenoiser(fs, 6, mk[1], mk[0]), fs, line_freq)))
    best_mu = min([0.001, 0.005, 0.02, 0.08], key=lambda mu: score(Notched(NLMSDenoiser(fs, line_freq, mu), fs, line_freq)))
    return dict(wavelet_mode=best_w[0], wavelet_k=best_w[1], nlms_mu=best_mu)


def build_baselines(fs, line_freq, hp):
    return {
        'Band-pass only': Notched(FilterOnly(), fs, line_freq),
        'ICA': Notched(ICADenoiser(fs), fs, line_freq),
        'NLMS': Notched(NLMSDenoiser(fs, line_freq, hp['nlms_mu']), fs, line_freq),
        'Wavelet': Notched(WaveletDenoiser(fs, 6, hp['wavelet_k'], hp['wavelet_mode']), fs, line_freq),
    }


def run_benchmark(clean, y, fs, cue, line_freq, methods, kinds=('eog', 'emg', 'motion', 'line', 'mixed'),
                  snrs=(-5.0, 0.0, 5.0), seed=7, cfg=None, verbose=True, keep=None):
    """Returns a tidy DataFrame (one row per method x artifact x SNR).  If `keep` is a dict, the
    denoised outputs are stored in keep[(kind,snr,method)] for plotting."""
    ref = eval_filter(clean, fs)
    nref = NIPIReference(ref, fs, y, cue, cfg or NIPIConfig())
    rows = []
    for kind in kinds:
        for snr in snrs:
            cont, art = simulate_artifacts(clean, fs, kind, snr, seed=seed, line_freq=line_freq)
            contf = eval_filter(cont, fs)
            allm = {'Contaminated': None, **methods}
            for name, m in allm.items():
                t0 = time.time()
                den = contf if m is None else eval_filter(m.denoise(cont), fs)
                dt = time.time() - t0
                sc = nref.score(den)
                row = dict(method=name, artifact=kind, snr=snr, rRMSE=rrmse(ref, den), RMSE=rmse(ref, den),
                           CC=cc(ref, den), RER=rer(ref, contf, den), SNR_out=snr_db(ref, den),
                           MI_IC=gaussian_mi_coefficient(ref, den, fs), time_s=dt)
                row.update({k: v for k, v in sc.items() if not k.startswith('_') or k in ('_auc_den',)})
                rows.append(row)
                if keep is not None:
                    keep[(kind, snr, name)] = den
            if keep is not None:
                keep[(kind, snr, 'clean')] = ref
                keep[(kind, snr, 'artifact')] = art
        if verbose:
            print(f'  finished artifact = {kind}', flush=True)
    return pd.DataFrame(rows)
