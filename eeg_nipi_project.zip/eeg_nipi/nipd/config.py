"""Global constants: the common 19-electrode 10-20 montage, EEG bands, scalp geometry."""
import numpy as np

# The same 19 electrodes used for all three datasets in Review 1.
CH_NAMES = ['Fp1', 'Fp2', 'F7', 'F3', 'Fz', 'F4', 'F8', 'T7', 'C3', 'Cz',
            'C4', 'T8', 'P7', 'P3', 'Pz', 'P4', 'P8', 'O1', 'O2']

# Old 10-20 names -> modern names (Siena uses T3/T4/T5/T6)
ALIASES = {'T3': 'T7', 'T4': 'T8', 'T5': 'P7', 'T6': 'P8'}

# Approximate 2-D scalp layout (x: left->right, y: back->front, head radius = 1)
POS = {
    'Fp1': (-0.30, 0.90), 'Fp2': (0.30, 0.90),
    'F7': (-0.78, 0.55), 'F3': (-0.40, 0.55), 'Fz': (0.0, 0.55), 'F4': (0.40, 0.55), 'F8': (0.78, 0.55),
    'T7': (-0.95, 0.0), 'C3': (-0.50, 0.0), 'Cz': (0.0, 0.0), 'C4': (0.50, 0.0), 'T8': (0.95, 0.0),
    'P7': (-0.78, -0.55), 'P3': (-0.40, -0.55), 'Pz': (0.0, -0.55), 'P4': (0.40, -0.55), 'P8': (0.78, -0.55),
    'O1': (-0.30, -0.90), 'O2': (0.30, -0.90),
}

BANDS = {'delta': (1.0, 4.0), 'theta': (4.0, 8.0), 'alpha': (8.0, 13.0),
         'beta': (13.0, 30.0), 'gamma': (30.0, 45.0)}

EVAL_BAND = (1.0, 45.0)   # neural band in which every method is scored


def positions(names=CH_NAMES):
    return np.array([POS[c] for c in names], dtype=float)


def ch_index(name, names=CH_NAMES):
    return names.index(name)
