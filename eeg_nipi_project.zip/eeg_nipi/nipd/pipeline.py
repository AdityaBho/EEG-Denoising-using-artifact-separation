"""End-to-end experiment on a set of CLEAN epochs (synthetic or real-data-derived).

  1. split  : train (learn EMG signature) / tune (baseline + NIPI feedback loop) / test (report)
  2. Stage 1: NIPD.fit()                      -> artifact signatures
  3. Stage 2: NIPI feedback loop (lambda=0 'conventional' vs lambda>0 'information-preserving')
  4. Stage 3: benchmark vs baselines on held-out epochs, NIPI + conventional metrics
  5. NIPI validation + figures + markdown summary
"""
import os, json, time
import numpy as np
import pandas as pd

from .nipd import NIPD, NIPDParams
from .tune import tune_nipd
from .evaluate import tune_baselines, build_baselines, run_benchmark
from .validation import run_validation
from . import plots
from .dsp import eval_filter


def run_pipeline(clean, y, fs, cue, line_freq, out_dir, lam=1.0, quick=False, tag='', extra_methods=None, seed=0):
    os.makedirs(out_dir, exist_ok=True)
    N = len(clean)
    n_tr, n_tu = int(0.35 * N), int(0.25 * N)
    sl = dict(train=slice(0, n_tr), tune=slice(n_tr, n_tr + n_tu), test=slice(n_tr + n_tu, N))
    Xtr, Xtu, Xte = clean[sl['train']], clean[sl['tune']], clean[sl['test']]
    ytu = None if y is None else y[sl['tune']]
    yte = None if y is None else y[sl['test']]
    print(f'[split] train={len(Xtr)} tune={len(Xtu)} test={len(Xte)} epochs', flush=True)

    t0 = time.time()
    print('[Stage 1] learning the EMG spectral signature ...', flush=True)
    base = NIPD(fs, line_freq).fit(Xtr, seed=seed)
    print('[baselines] tuning wavelet / NLMS hyper-parameters on the tuning split ...', flush=True)
    hp = tune_baselines(Xtu, fs, line_freq)
    print('   ->', hp, flush=True)

    nr, nl = (6, 6) if quick else (22, 18)
    hist, best = {}, {}
    for lam_ in (0.0, lam):
        print(f'[Stage 2] NIPI feedback loop, lambda={lam_}', flush=True)
        p, h = tune_nipd(base, Xtu, ytu, fs, cue, line_freq, lam=lam_, n_random=nr, n_local=nl, seed=seed)
        best[lam_], hist[lam_] = p, h
    json.dump({str(k): v.as_dict() for k, v in best.items()}, open(os.path.join(out_dir, 'tuned_params.json'), 'w'), indent=2)
    json.dump(hp, open(os.path.join(out_dir, 'baseline_hparams.json'), 'w'), indent=2)

    def mk(p):
        m = NIPD(fs, line_freq, p)
        m.rho, m.rho_f, m.hf_floor, m.hf_band = base.rho, base.rho_f, base.hf_floor, base.hf_band
        return m
    m0, m1 = mk(best[0.0]), mk(best[lam])
    m0.name, m1.name = 'NIPD (MSE-only, lam=0)', 'NIPD (NIPI-guided)'
    methods = build_baselines(fs, line_freq, hp)
    methods[m0.name] = m0
    methods[m1.name] = m1
    if extra_methods:
        methods.update(extra_methods)

    print('[Stage 3] benchmark on held-out test epochs ...', flush=True)
    keep = {}
    snrs = (-5.0, 0.0) if quick else (-5.0, 0.0, 5.0)
    df = run_benchmark(Xte, yte, fs, cue, line_freq, methods, snrs=snrs, keep=keep)
    df.to_csv(os.path.join(out_dir, 'benchmark_full.csv'), index=False)

    print('[Stage 3] NIPI metric validation ...', flush=True)
    vdf = run_validation(Xte, yte, fs, cue) if yte is not None else None
    if vdf is not None:
        vdf.to_csv(os.path.join(out_dir, 'nipi_validation.csv'), index=False)

    # ---------------------------------------------------------------- figures
    print('[figures] ...', flush=True)
    fdir = os.path.join(out_dir, 'figures')
    os.makedirs(fdir, exist_ok=True)
    show = ['ICA', 'Wavelet', m0.name, m1.name]
    plots.fig_graph(os.path.join(fdir, 'fig01_electrode_graph.png'))
    plots.fig_example(keep, fs, show, 'mixed', 0.0, os.path.join(fdir, 'fig02_example_mixed.png'))
    plots.fig_example(keep, fs, show, 'eog', 0.0, os.path.join(fdir, 'fig03_example_eog.png'), ch=('Fp1', 'Cz', 'O1'))
    plots.fig_psd(keep, fs, show, 'mixed', 0.0, os.path.join(fdir, 'fig04_psd_mixed.png'))
    plots.fig_metric_vs_snr(df, os.path.join(fdir, 'fig05_NIPI_vs_snr.png'), 'NIPI')
    plots.fig_metric_vs_snr(df, os.path.join(fdir, 'fig06_rRMSE_vs_snr.png'), 'rRMSE')
    plots.fig_components(df, os.path.join(fdir, 'fig07_nipi_components.png'), 'mixed', 0.0,
                         ['Contaminated', 'ICA', 'NLMS', 'Wavelet', m0.name, m1.name])
    plots.fig_pareto(df[df.method != 'Contaminated'], os.path.join(fdir, 'fig08_pareto.png'), history=hist)
    if vdf is not None:
        plots.fig_validation(vdf, os.path.join(fdir, 'fig09_nipi_validation.png'))
    cont, art = __import__('nipd.synthetic', fromlist=['x']).simulate_artifacts(Xte, fs, 'mixed', 0.0, seed=7, line_freq=line_freq)
    _, parts = m1.denoise(cont, return_parts=True)
    plots.fig_stage1(cont, parts, eval_filter(Xte, fs), fs, os.path.join(fdir, 'fig10_stage1_artifact_estimates.png'))

    # ---------------------------------------------------------------- summary tables
    summ = summarize(df)
    summ.to_csv(os.path.join(out_dir, 'summary_by_method.csv'))
    with open(os.path.join(out_dir, 'SUMMARY.md'), 'w') as f:
        f.write(f'# Results {tag}\n\nTest epochs: {len(Xte)}, fs={fs} Hz, mains={line_freq} Hz, lambda={lam}\n\n')
        f.write('## Mean over all artifacts and SNRs (higher NIPI / CC / SNR_out and lower rRMSE / RER are better)\n\n')
        f.write(summ.round(3).to_markdown() + '\n\n')
        f.write('## Mixed artifacts, input SNR 0 dB\n\n')
        d = df[(df.artifact == 'mixed') & (df.snr == 0.0)].set_index('method')
        cols = [c for c in ['rRMSE', 'CC', 'RER', 'NIPI', 'S', 'P', 'C', 'E', 'H', 'D', 'MI_IC'] if c in d.columns]
        f.write(d[cols].round(3).to_markdown() + '\n\n')
        if vdf is not None:
            f.write('## NIPI metric validation (controlled degradations)\n\n' + vdf.round(3).to_markdown(index=False) + '\n\n')
        f.write('## Tuned NIPD parameters\n\n```json\n' + json.dumps({str(k): v.as_dict() for k, v in best.items()}, indent=1) + '\n```\n')
    print(f'[done] {time.time() - t0:.0f}s  ->  {out_dir}', flush=True)
    return df, vdf, best


def summarize(df):
    cols = [c for c in ['NIPI', 'S', 'P', 'C', 'E', 'H', 'D', 'MI_IC', 'rRMSE', 'CC', 'RER', 'SNR_out', 'time_s'] if c in df.columns]
    return df.groupby('method')[cols].mean().sort_values('NIPI', ascending=False)
