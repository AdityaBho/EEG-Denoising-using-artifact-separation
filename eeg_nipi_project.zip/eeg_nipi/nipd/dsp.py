"""Small DSP helpers (zero-phase filters, PSD, analytic signal)."""
import numpy as np
from scipy import signal


def _nyq_clip(hi, fs):
    return min(hi, 0.98 * fs / 2.0)


def bandpass(x, lo, hi, fs, order=4):
    hi = _nyq_clip(hi, fs)
    sos = signal.butter(order, [lo, hi], btype='band', fs=fs, output='sos')
    return signal.sosfiltfilt(sos, x, axis=-1)


def lowpass(x, fc, fs, order=4):
    sos = signal.butter(order, _nyq_clip(fc, fs), btype='low', fs=fs, output='sos')
    return signal.sosfiltfilt(sos, x, axis=-1)


def highpass(x, fc, fs, order=4):
    sos = signal.butter(order, fc, btype='high', fs=fs, output='sos')
    return signal.sosfiltfilt(sos, x, axis=-1)


def rms(x, axis=None, keepdims=False):
    return np.sqrt(np.mean(np.square(x), axis=axis, keepdims=keepdims))


def welch_psd(x, fs, nperseg=None):
    T = x.shape[-1]
    nperseg = nperseg or min(T, int(fs))
    f, p = signal.welch(x, fs=fs, nperseg=nperseg, noverlap=nperseg // 2, axis=-1)
    return f, p


def eval_filter(x, fs):
    """Common post-filter applied to EVERY method's output before scoring (1-45 Hz)."""
    from .config import EVAL_BAND
    return bandpass(x, EVAL_BAND[0], EVAL_BAND[1], fs)
