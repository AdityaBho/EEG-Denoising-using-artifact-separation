"""All figures used for the panel presentation (saved as PNG, 200 dpi)."""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.interpolate import griddata
from .config import CH_NAMES, positions
from .dsp import welch_psd
from .graph import electrode_graph

PAL = {'Contaminated': '#9a9a9a', 'Band-pass only': '#c7a97a', 'ICA': '#2a7ab0', 'NLMS': '#8a5fb5',
       'Wavelet': '#4fa36b', 'NIPD (MSE-only, lam=0)': '#e08a1e', 'NIPD (NIPI-guided)': '#c8262e'}
plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.grid': True, 'grid.alpha': .25, 'figure.dpi': 110})


def _col(m):
    return PAL.get(m, '#444444')


def fig_graph(path):
    A, L, w, U = electrode_graph()
    P = positions()
    fig, ax = plt.subplots(1, 3, figsize=(13, 4.2))
    th = np.linspace(0, 2 * np.pi, 200)
    ax[0].plot(np.cos(th), np.sin(th), 'k', lw=1)
    for i in range(len(P)):
        for j in range(i + 1, len(P)):
            if A[i, j] > 0:
                ax[0].plot(P[[i, j], 0], P[[i, j], 1], color='#2a7ab0', lw=0.5 + 2.5 * A[i, j], alpha=.7)
    ax[0].scatter(P[:, 0], P[:, 1], s=260, c='w', ec='k', zorder=3)
    for i, n in enumerate(CH_NAMES):
        ax[0].text(P[i, 0], P[i, 1], n, ha='center', va='center', fontsize=7, zorder=4)
    ax[0].set_title('Electrode graph (19 nodes, k-NN Gaussian edges)')
    ax[0].axis('equal'); ax[0].axis('off')
    ax[1].bar(range(len(w)), w, color='#2a7ab0'); ax[1].set_title('Graph spectrum (Laplacian eigenvalues)')
    ax[1].set_xlabel('graph frequency index'); ax[1].set_ylabel('$\\lambda$')
    topo(ax[2], U[:, 18], 'Highest graph-frequency mode\n(spatially rough = artifact-like)')
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def topo(ax, v, title='', cmap='RdBu_r'):
    P = positions()
    gx, gy = np.meshgrid(np.linspace(-1.05, 1.05, 120), np.linspace(-1.05, 1.05, 120))
    gz = griddata(P, v, (gx, gy), method='cubic')
    gz[(gx ** 2 + gy ** 2) > 1.0] = np.nan
    m = np.nanmax(np.abs(v)) + 1e-12
    ax.imshow(gz, extent=(-1.05, 1.05, -1.05, 1.05), origin='lower', cmap=cmap, vmin=-m, vmax=m)
    th = np.linspace(0, 2 * np.pi, 200)
    ax.plot(np.cos(th), np.sin(th), 'k', lw=1)
    ax.plot([-0.1, 0, 0.1], [1.0, 1.1, 1.0], 'k', lw=1)
    ax.scatter(P[:, 0], P[:, 1], s=8, c='k')
    ax.set_title(title, fontsize=9); ax.axis('off'); ax.set_aspect('equal')


def fig_example(keep, fs, methods, kind, snr, path, ch=('Fp1', 'Cz'), epoch=0, t_win=(0, 4)):
    n = len(ch)
    fig, axes = plt.subplots(n, 1, figsize=(12, 3.2 * n), sharex=True)
    axes = np.atleast_1d(axes)
    t = np.arange(keep[(kind, snr, 'clean')].shape[-1]) / fs
    for ax, c in zip(axes, ch):
        i = CH_NAMES.index(c)
        ax.plot(t, keep[(kind, snr, 'Contaminated')][epoch, i], color=_col('Contaminated'), lw=.8, label='Contaminated')
        ax.plot(t, keep[(kind, snr, 'clean')][epoch, i], 'k', lw=1.4, label='Clean (ground truth)')
        for m in methods:
            ax.plot(t, keep[(kind, snr, m)][epoch, i], color=_col(m), lw=1.0, label=m, alpha=.9)
        ax.set_ylabel(f'{c} (µV)')
    axes[0].legend(ncol=4, fontsize=8, loc='upper right')
    axes[-1].set_xlabel('time (s)')
    axes[0].set_title(f'Example epoch - {kind}, SNR {snr:+.0f} dB')
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def fig_psd(keep, fs, methods, kind, snr, path):
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    for a, ylog in zip(ax, (True, False)):
        f, p = welch_psd(keep[(kind, snr, 'clean')], fs)
        m = (f >= 1) & (f <= 45)
        a.plot(f[m], p.mean((0, 1))[m], 'k', lw=2, label='Clean')
        for k in ['Contaminated'] + list(methods):
            f, p = welch_psd(keep[(kind, snr, k)], fs)
            a.plot(f[m], p.mean((0, 1))[m], color=_col(k), lw=1.2, label=k)
        if ylog:
            a.set_yscale('log')
        a.set_xlabel('Hz'); a.set_ylabel('PSD (µV²/Hz)')
    ax[0].set_title(f'Power spectrum (log) - {kind}, {snr:+.0f} dB'); ax[1].set_title('linear')
    ax[0].legend(fontsize=7)
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def fig_metric_vs_snr(df, path, metric='NIPI', methods=None):
    kinds = [k for k in ['eog', 'emg', 'motion', 'line', 'mixed'] if k in df.artifact.unique()]
    methods = methods or [m for m in df.method.unique()]
    fig, axes = plt.subplots(1, len(kinds), figsize=(3.3 * len(kinds), 3.6), sharey=True)
    axes = np.atleast_1d(axes)
    for ax, k in zip(axes, kinds):
        for m in methods:
            d = df[(df.artifact == k) & (df.method == m)].sort_values('snr')
            ax.plot(d.snr, d[metric], '-o', color=_col(m), ms=4, label=m, lw=2 if 'NIPD' in m else 1.2)
        ax.set_title(k.upper()); ax.set_xlabel('input SNR (dB)')
    axes[0].set_ylabel(metric)
    axes[-1].legend(fontsize=7, loc='lower right')
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def fig_components(df, path, kind='mixed', snr=0.0, methods=None):
    comps = [c for c in ['S', 'P', 'C', 'E', 'H', 'D'] if c in df.columns and df[c].notna().any()]
    names = {'S': 'Spectral', 'P': 'Phase-lock', 'C': 'Connectivity', 'E': 'ERP', 'H': 'Entropy', 'D': 'Discriminab.'}
    d = df[(df.artifact == kind) & (df.snr == snr)]
    methods = methods or list(d.method)
    fig, ax = plt.subplots(figsize=(11, 4))
    w = 0.8 / len(methods)
    for i, m in enumerate(methods):
        r = d[d.method == m].iloc[0]
        ax.bar(np.arange(len(comps) + 1) + i * w, [r[c] for c in comps] + [r['NIPI']], w, color=_col(m), label=m)
    ax.set_xticks(np.arange(len(comps) + 1) + 0.4 - w / 2)
    ax.set_xticklabels([names[c] for c in comps] + ['NIPI'])
    ax.set_ylim(0, 1.05); ax.set_ylabel('score (1 = information fully preserved)')
    ax.set_title(f'NIPI components - {kind}, input SNR {snr:+.0f} dB')
    ax.legend(fontsize=7, ncol=4, loc='lower left')
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def fig_pareto(df, path, history=None):
    g = df.groupby('method')[['RER', 'NIPI']].mean()
    fig, ax = plt.subplots(1, 2 if history else 1, figsize=(11 if history else 5.5, 4.4))
    ax0 = ax[0] if history else ax
    for m, r in g.iterrows():
        ax0.scatter(r.RER, r.NIPI, s=110, color=_col(m), zorder=3)
        ax0.annotate(m, (r.RER, r.NIPI), fontsize=8, xytext=(5, 4), textcoords='offset points')
    ax0.set_xlabel('Residual Error Ratio  (lower = more artifact energy removed)')
    ax0.set_ylabel('NIPI  (higher = more neural information kept)')
    ax0.set_title('Artifact suppression vs. information preservation\n(mean over all artifacts & SNRs)')
    if history:
        for lam, h in history.items():
            ax[1].scatter([x['RER'] for x in h], [x['NIPI'] for x in h], s=14, alpha=.6, label=f'search, $\\lambda$={lam}')
        ax[1].set_xlabel('RER (tuning set)'); ax[1].set_ylabel('NIPI (tuning set)')
        ax[1].set_title('NIPI feedback loop: candidate settings'); ax[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def fig_validation(vdf, path):
    d = vdf.sort_values('rRMSE')
    y = np.arange(len(d))
    fig, ax = plt.subplots(figsize=(10, 4.6))
    ax.barh(y + .2, d.CC, .38, color='#2a7ab0', label='Correlation (CC)')
    ax.barh(y - .2, d.NIPI, .38, color='#c8262e', label='NIPI')
    ax.set_yticks(y); ax.set_yticklabels([f'{n}  (rRMSE {r:.2f})' for n, r in zip(d.degradation, d.rRMSE)], fontsize=8)
    ax.set_xlim(0, 1.05); ax.legend(loc='lower right')
    ax.set_title('Controlled degradations: conventional correlation vs NIPI')
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def fig_stage1(X_cont, parts, X_clean, fs, path, epoch=0):
    """Stage-1 'artifact characterisation': what the model attributes to each artifact class."""
    order = ['line', 'eog', 'motion', 'emg']
    P = positions()
    t = np.arange(X_cont.shape[-1]) / fs
    fig = plt.figure(figsize=(13, 7))
    gs = fig.add_gridspec(len(order) + 1, 3, width_ratios=[3, 3, 1.4])
    ch_show = {'line': 'Cz', 'eog': 'Fp1', 'motion': None, 'emg': 'T7'}
    ax = fig.add_subplot(gs[0, :2])
    ax.plot(t, X_cont[epoch, CH_NAMES.index('Fp1')], color='#999', lw=.8, label='Fp1 contaminated')
    ax.plot(t, X_clean[epoch, CH_NAMES.index('Fp1')], 'k', lw=1.2, label='Fp1 clean')
    ax.legend(fontsize=8, loc='upper right'); ax.set_title('Input', loc='left', fontsize=9)
    for r, k in enumerate(order, start=1):
        a = parts[k][epoch]
        c = ch_show[k] or CH_NAMES[int(np.argmax(np.abs(a).max(1)))]
        axx = fig.add_subplot(gs[r, :2], sharex=ax)
        axx.plot(t, a[CH_NAMES.index(c)], color='#c8262e', lw=1)
        axx.set_ylabel(f'{k.upper()}\n{c}', fontsize=8)
        tp = fig.add_subplot(gs[r, 2])
        topo(tp, np.sqrt((a ** 2).mean(1)), 'RMS topography' if r == 1 else '', cmap='viridis')
    ax.set_xlabel('')
    fig.suptitle('Stage 1 - artifact characterisation: estimated EOG / motion / EMG / line components', y=.995)
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)
