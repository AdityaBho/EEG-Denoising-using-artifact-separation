"""NIPD-Net : the neural (deep-learning) Stage 2, trained with a NIPI-surrogate loss.

REQUIRES PyTorch (pip install torch).  Kept in one file so it is easy to explain:

  NIPDNet      attention-guided 1-D U-Net.  It does NOT output the clean EEG directly; it outputs an
               ARTIFACT estimate  a_hat = gate * residual  and the denoised EEG is  x - a_hat.
               gate in [0,1] (sigmoid, per electrode and time-point) is the 'attention' that decides where
               removal is allowed -> where the gate is 0 the neural signal passes through untouched.
                 * graph-initialised spatial mixing layer  (electrode-graph prior, GSP)
                 * squeeze-excitation channel attention in every block
                 * temporal multi-head self-attention in the bottleneck (global context)
  NIPILoss     differentiable surrogates of the NIPI components:
                 time   : MSE to the clean EEG                 (the conventional objective)
                 spec   : log-spectral L1                       <-> S (spectral consistency)
                 phase  : magnitude-weighted 1-cos(dphi)         <-> P (phase-locking)
                 conn   : inter-electrode coherence L1           <-> C (connectivity)
                 riem   : log-det (Jensen-Bregman) divergence of covariances  (Riemannian geometry)
                 mi     : 1 - r_I^2 from Gaussian mutual information  (information-theoretic term, optional)
  objective='mse'  -> conventional denoising autoencoder (all lambdas = 0)
  objective='nipi' -> proposed information-preserving objective
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .graph import electrode_graph


# ----------------------------------------------------------------------------------------------
class SE(nn.Module):
    """Squeeze-and-excitation channel attention for (B, ch, T)."""
    def __init__(self, ch, r=4):
        super().__init__()
        self.f1 = nn.Linear(ch, max(ch // r, 4))
        self.f2 = nn.Linear(max(ch // r, 4), ch)

    def forward(self, x):
        s = torch.sigmoid(self.f2(F.relu(self.f1(x.mean(-1)))))
        return x * s.unsqueeze(-1)


class Block(nn.Module):
    def __init__(self, cin, cout, k=7):
        super().__init__()
        self.c1 = nn.Conv1d(cin, cout, k, padding=k // 2)
        self.n1 = nn.GroupNorm(8, cout)
        self.c2 = nn.Conv1d(cout, cout, k, padding=k // 2)
        self.n2 = nn.GroupNorm(8, cout)
        self.se = SE(cout)
        self.skip = nn.Conv1d(cin, cout, 1) if cin != cout else nn.Identity()

    def forward(self, x):
        h = F.gelu(self.n1(self.c1(x)))
        h = self.n2(self.c2(h))
        h = self.se(h)
        return F.gelu(h + self.skip(x))


def sinusoid(L, d, device):
    pos = torch.arange(L, device=device).float().unsqueeze(1)
    i = torch.arange(0, d, 2, device=device).float()
    ang = pos / torch.pow(10000.0, i / d)
    pe = torch.zeros(L, d, device=device)
    pe[:, 0::2] = torch.sin(ang)
    pe[:, 1::2] = torch.cos(ang)
    return pe


class NIPDNet(nn.Module):
    def __init__(self, n_ch=19, base=32, heads=4):
        super().__init__()
        self.n_ch = n_ch
        self.spatial = nn.Conv1d(n_ch, n_ch, 1, bias=False)           # electrode mixing (graph-initialised)
        with torch.no_grad():
            A, _, _, _ = electrode_graph()
            An = A / A.sum(1, keepdims=True)
            w = 0.6 * np.eye(n_ch) + 0.4 * An
            self.spatial.weight.copy_(torch.tensor(w, dtype=torch.float32).unsqueeze(-1))
        self.e0 = Block(n_ch, base)
        self.d1 = nn.Conv1d(base, base * 2, 4, stride=2, padding=1)
        self.e1 = Block(base * 2, base * 2)
        self.d2 = nn.Conv1d(base * 2, base * 4, 4, stride=2, padding=1)
        self.e2 = Block(base * 4, base * 4)
        self.d3 = nn.Conv1d(base * 4, base * 4, 4, stride=2, padding=1)
        layer = nn.TransformerEncoderLayer(d_model=base * 4, nhead=heads, dim_feedforward=base * 8,
                                           dropout=0.0, batch_first=True, activation='gelu')
        self.attn = nn.TransformerEncoder(layer, num_layers=2)
        self.u2 = Block(base * 8, base * 4)
        self.u1 = Block(base * 4 + base * 2, base * 2)
        self.u0 = Block(base * 2 + base, base)
        self.res = nn.Conv1d(base, n_ch, 1)                          # raw artifact estimate
        self.gate = nn.Conv1d(base, n_ch, 1)                         # attention gate in [0,1]
        nn.init.constant_(self.gate.bias, 0.0)

    def forward(self, x):
        B, C, T = x.shape
        pad = (-T) % 8
        if pad:
            x = F.pad(x, (0, pad), mode='replicate')
        s = x.std(dim=(1, 2), keepdim=True) + 1e-6
        xn = x / s
        h = self.spatial(xn)
        e0 = self.e0(h)                                              # (B,b,T)
        e1 = self.e1(self.d1(e0))                                    # (B,2b,T/2)
        e2 = self.e2(self.d2(e1))                                    # (B,4b,T/4)
        z = self.d3(e2)                                              # (B,4b,T/8)
        zt = z.transpose(1, 2)                                       # (B,L,d)
        zt = zt + sinusoid(zt.shape[1], zt.shape[2], zt.device).unsqueeze(0)
        z = self.attn(zt).transpose(1, 2)                            # global temporal attention
        u2 = self.u2(torch.cat([F.interpolate(z, size=e2.shape[-1], mode='nearest'), e2], 1))
        u1 = self.u1(torch.cat([F.interpolate(u2, size=e1.shape[-1], mode='nearest'), e1], 1))
        u0 = self.u0(torch.cat([F.interpolate(u1, size=e0.shape[-1], mode='nearest'), e0], 1))
        a_hat = torch.sigmoid(self.gate(u0)) * self.res(u0)          # gated artifact estimate (normalised units)
        out = (xn - a_hat) * s
        return out[..., :T]


# ----------------------------------------------------------------------------------------------
class NIPILoss(nn.Module):
    """Differentiable NIPI surrogate.  All spectral terms are restricted to 1-45 Hz."""
    def __init__(self, fs, w_spec=0.5, w_phase=0.5, w_conn=1.0, w_riem=0.5, w_mi=0.0, n_fft=None):
        super().__init__()
        self.fs = fs
        self.n_fft = n_fft or int(2 ** np.round(np.log2(fs * 0.5)))     # ~0.5 s window
        self.hop = self.n_fft // 4
        self.register_buffer('win', torch.hann_window(self.n_fft))
        f = torch.fft.rfftfreq(self.n_fft, 1.0 / fs)
        self.register_buffer('mask', (f >= 1.0) & (f <= 45.0))
        self.w = dict(spec=w_spec, phase=w_phase, conn=w_conn, riem=w_riem, mi=w_mi)

    def stft(self, x):
        B, C, T = x.shape
        X = torch.stft(x.reshape(B * C, T), n_fft=self.n_fft, hop_length=self.hop, win_length=self.n_fft,
                       window=self.win, center=True, return_complex=True)
        return X.reshape(B, C, X.shape[-2], X.shape[-1])[:, :, self.mask]     # (B,C,F',Tf)

    @staticmethod
    def _cov(x, jitter=1e-3):
        xc = x - x.mean(-1, keepdim=True)
        C = xc @ xc.transpose(1, 2) / x.shape[-1]
        tr = torch.diagonal(C, dim1=1, dim2=2).sum(-1) / C.shape[1]
        return C + (jitter * tr + 1e-6).view(-1, 1, 1) * torch.eye(C.shape[1], device=x.device)

    def forward(self, den, ref):
        scale = ref.std() + 1e-6
        den, ref = den / scale, ref / scale                                       # unit-variance units
        terms = {'time': F.mse_loss(den, ref)}
        X, Xh = self.stft(ref), self.stft(den)
        P, Ph = X.real ** 2 + X.imag ** 2, Xh.real ** 2 + Xh.imag ** 2
        terms['spec'] = (torch.log(Ph + 1e-4) - torch.log(P + 1e-4)).abs().mean()
        mag, magh = torch.sqrt(P + 1e-8), torch.sqrt(Ph + 1e-8)
        cosd = (Xh * X.conj()).real / (mag * magh + 1e-8)
        terms['phase'] = ((1 - cosd) * mag).sum() / (mag.sum() + 1e-8)
        def coh(Z):
            cs = torch.einsum('bcft,bdft->bcdf', Z, Z.conj()) / Z.shape[-1]
            dg = torch.diagonal(cs, dim1=1, dim2=2).real                           # (B,F,C)
            nrm = torch.sqrt(dg.unsqueeze(-1) * dg.unsqueeze(-2) + 1e-8).permute(0, 2, 3, 1)  # (B,C,C,F)
            return (cs.abs() / nrm).mean(-1)                                       # (B,C,C)
        terms['conn'] = (coh(Xh) - coh(X)).abs().mean()
        A, Bm = self._cov(den), self._cov(ref)
        ld = lambda M: torch.linalg.slogdet(M)[1]
        terms['riem'] = (ld(0.5 * (A + Bm)) - 0.5 * (ld(A) + ld(Bm))).mean() / den.shape[1]
        if self.w['mi'] > 0:
            J = self._cov(torch.cat([ref, den], 1))
            I = 0.5 * (ld(Bm) + ld(A) - ld(J))
            terms['mi'] = torch.exp(-2 * I / den.shape[1]).mean()
        total = terms['time'] + sum(self.w[k] * terms[k] for k in self.w if k in terms and self.w[k] > 0)
        return total, {k: float(v.detach()) for k, v in terms.items()}


# ----------------------------------------------------------------------------------------------
def train_nipdnet(X_cont, X_ref, fs, objective='nipi', epochs=40, batch=32, lr=1e-3, device=None, seed=0,
                  verbose=True, **loss_kw):
    """X_cont / X_ref : numpy (N,C,T) contaminated input / clean reference (both in uV)."""
    torch.manual_seed(seed)
    np.random.seed(seed)
    device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
    model = NIPDNet(X_cont.shape[1]).to(device)
    if objective == 'mse':
        crit = NIPILoss(fs, 0, 0, 0, 0, 0).to(device)
    else:
        crit = NIPILoss(fs, **loss_kw).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    Xc = torch.tensor(X_cont, dtype=torch.float32)
    Xr = torch.tensor(X_ref, dtype=torch.float32)
    n = len(Xc)
    for ep in range(epochs):
        model.train()
        perm = torch.randperm(n)
        tot = 0.0
        for i in range(0, n, batch):
            idx = perm[i:i + batch]
            xb, rb = Xc[idx].to(device), Xr[idx].to(device)
            out = model(xb)
            loss, parts = crit(out, rb)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            tot += float(loss.detach()) * len(idx)
        sched.step()
        if verbose and (ep % 5 == 0 or ep == epochs - 1):
            print(f'    [{objective}] epoch {ep + 1:3d}/{epochs}  loss {tot / n:.4f}  ' +
                  ' '.join(f'{k}={v:.3f}' for k, v in parts.items()), flush=True)
    model.eval()
    return model


class NNDenoiser:
    """Wraps a trained NIPDNet in the common .denoise(X) interface used by the benchmark harness."""
    def __init__(self, model, name, device=None, batch=64):
        self.model, self.name = model, name
        self.device = device or next(model.parameters()).device
        self.batch = batch

    def denoise(self, X):
        out = []
        self.model.eval()
        with torch.no_grad():
            for i in range(0, len(X), self.batch):
                xb = torch.tensor(X[i:i + self.batch], dtype=torch.float32, device=self.device)
                out.append(self.model(xb).cpu().numpy())
        return np.concatenate(out, 0).astype(float)
