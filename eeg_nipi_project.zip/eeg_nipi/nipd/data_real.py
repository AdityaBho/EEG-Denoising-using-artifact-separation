"""Loaders for the three Review-1 datasets -> clean 19-electrode epochs.

Requires `mne` (pip install mne) to read EDF/BDF/FIF/SET files.  Output of every loader:
    X  (N, 19, T)  micro-volts, notch + 1-45 Hz band-passed ("clean reference" epochs)
    y  (N,) class labels or None,    fs (Hz),    cue_time (s) or None

NOTE on "clean": real recordings have no perfect ground truth.  We keep only the cleanest epochs
(select_clean_epochs) and then ADD simulated artifacts of known type/SNR (semi-synthetic protocol used
by EEGdenoiseNet and the papers in the Review-1 literature survey).
"""
import glob, os
import numpy as np
from scipy import signal
from .config import CH_NAMES, ALIASES
from .dsp import bandpass, highpass

_CANON = {c.upper(): c for c in CH_NAMES}


def _canon(name):
    n = name.strip().upper().replace('EEG ', '').replace('EEG-', '')
    for suf in ('-REF', '-LE', '-AV', '-M1', '-M2', '-A1', '-A2'):
        n = n.replace(suf, '')
    n = n.strip('. ').replace(' ', '')
    n = {k.upper(): v for k, v in ALIASES.items()}.get(n, n)
    return _CANON.get(n.upper())


def _read_raw(path):
    import mne
    mne.set_log_level('ERROR')
    ext = os.path.splitext(path)[1].lower()
    if ext in ('.edf',):
        raw = mne.io.read_raw_edf(path, preload=True, verbose='ERROR')
    elif ext in ('.bdf',):
        raw = mne.io.read_raw_bdf(path, preload=True, verbose='ERROR')
    elif ext in ('.fif',):
        raw = mne.io.read_raw_fif(path, preload=True, verbose='ERROR')
    elif ext in ('.set',):
        raw = mne.io.read_raw_eeglab(path, preload=True, verbose='ERROR')
    elif ext in ('.vhdr',):
        raw = mne.io.read_raw_brainvision(path, preload=True, verbose='ERROR')
    else:
        raise ValueError(f'unsupported file type: {path}')
    return raw


def raw_to_19(raw, fs_target=None):
    """-> (data (19,T) in uV in CH_NAMES order, fs).  Raises with a clear message if electrodes are missing."""
    mapping, seen = {}, set()
    for n in raw.ch_names:
        c = _canon(n)
        if c is not None and c not in seen:
            mapping[n] = c
            seen.add(c)
    missing = [c for c in CH_NAMES if c not in seen]
    if missing:
        raise ValueError(f'electrodes missing in {raw.filenames}: {missing}.\nChannels found: {raw.ch_names}')
    raw = raw.copy().pick(list(mapping.keys()))
    raw.rename_channels(mapping)
    raw.reorder_channels(CH_NAMES)
    if fs_target and abs(raw.info['sfreq'] - fs_target) > 1e-6:
        raw.resample(fs_target)
    return raw.get_data() * 1e6, float(raw.info['sfreq']), raw


def _prefilter(data, fs, line):
    from .evaluate import notch
    data = notch(data, fs, line)
    return bandpass(data, 1.0, 45.0, fs)


def select_clean_epochs(X, fs, keep_frac=0.6, max_ptp=150.0):
    """Keep the cleanest epochs: low peak-to-peak amplitude and low high-frequency (EMG-like) share."""
    ptp = (X.max(-1) - X.min(-1)).max(1)
    xb = bandpass(X, 20.0, 45.0, fs)
    hf = (xb ** 2).sum(-1) / ((X ** 2).sum(-1) + 1e-12)
    hf = hf.max(1)
    rk = lambda v: np.argsort(np.argsort(v)) / (len(v) - 1 + 1e-9)
    score = np.maximum(rk(ptp), rk(hf))
    ok = ptp < max_ptp
    order = np.argsort(np.where(ok, score, 9))
    keep = np.sort(order[:max(8, int(keep_frac * len(X)))])
    keep = keep[ok[keep]]
    return keep


# ---------------------------------------------------------------------------------------------
def load_eegmmidb(root, subjects=('S001', 'S002', 'S003'), runs=(4, 8, 12), line=60.0, keep_frac=0.6):
    """PhysioNet EEG Motor Movement/Imagery.  Runs 4/8/12 = imagined LEFT (T1) vs RIGHT (T2) fist.
    Epoch = [-1, +3] s around the cue (cue at 1.0 s).  64 electrodes -> the same 19 as Biosource."""
    import mne
    Xs, ys, fs = [], [], None
    for s in subjects:
        for r in runs:
            cand = glob.glob(os.path.join(root, '**', f'{s}R{r:02d}.edf'), recursive=True)
            if not cand:
                print(f'  [warn] {s}R{r:02d}.edf not found under {root}')
                continue
            data, fs, raw = raw_to_19(_read_raw(cand[0]))
            data = _prefilter(data, fs, line)
            ev, _ = mne.events_from_annotations(raw, event_id={'T1': 1, 'T2': 2}, verbose='ERROR')
            for samp, _, lab in ev:
                a, b = int(samp - 1.0 * fs), int(samp + 3.0 * fs)
                if a >= 0 and b <= data.shape[1]:
                    Xs.append(data[:, a:b]); ys.append(lab - 1)
    if not Xs:
        raise FileNotFoundError('no EEGMMIDB epochs found - check --path / --subjects')
    X, y = np.stack(Xs), np.array(ys)
    keep = select_clean_epochs(X, fs, keep_frac)
    print(f'[EEGMMIDB] {len(X)} epochs -> kept {len(keep)} cleanest; classes: {np.bincount(y[keep])}  fs={fs}')
    return X[keep], y[keep], fs, 1.0


def load_continuous(paths, line=50.0, fs_target=256.0, dur=4.0, keep_frac=0.6, max_epochs=400):
    """Siena Scalp EEG / Biosource / any continuous EDF: cut into non-overlapping `dur`-s windows.
    No event markers -> ERP (E) and discriminability (D) components are skipped by NIPI."""
    Xs, fs = [], None
    for p in paths:
        data, fs, _ = raw_to_19(_read_raw(p), fs_target)
        data = _prefilter(data, fs, line)
        T = int(dur * fs)
        for a in range(0, data.shape[1] - T, T):
            Xs.append(data[:, a:a + T])
    X = np.stack(Xs)
    keep = select_clean_epochs(X, fs, keep_frac)
    if len(keep) > max_epochs:
        keep = np.sort(np.random.default_rng(0).choice(keep, max_epochs, replace=False))
    print(f'[continuous] {len(X)} windows -> kept {len(keep)} cleanest;  fs={fs}')
    return X[keep], None, fs, None


def load_siena(root, line=50.0, max_files=3, **kw):
    files = sorted(glob.glob(os.path.join(root, '**', '*.edf'), recursive=True))[:max_files]
    if not files:
        raise FileNotFoundError(f'no .edf under {root}')
    return load_continuous(files, line=line, **kw)


def load_npy(path, fs, labels=None, cue=None):
    """Any pre-epoched data: array of shape (N, 19, T) in micro-volts, channel order = CH_NAMES."""
    X = np.load(path).astype(float)
    y = None if labels is None else np.load(labels)
    return X, y, float(fs), cue
