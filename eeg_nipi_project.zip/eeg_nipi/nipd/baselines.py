"""Baselines from Review 1 (ICA, NLMS adaptive filtering, wavelet thresholding) + 'filter only'.

All baselines are *unsupervised* (they only see the contaminated data) and share the same
interface:  .denoise(X) with X of shape (N, C, T)  ->  array of the same shape.
"""
import numpy as np
from scipy import signal, stats
from sklearn.decomposition import FastICA
from .config import CH_NAMES, ch_index
from .dsp import bandpass, lowpass, highpass, welch_psd

IDX = {c: i for i, c in enumerate(CH_NAMES)}
FRONT = [IDX[c] for c in ('Fp1', 'Fp2')]


# ----------------------------------------------------------------------------------
class FilterOnly:
    """No artifact removal other than the common 1-45 Hz band-pass (applied by the harness)."""
    name = 'Band-pass only'

    def denoise(self, X):
        return X.copy()


# ----------------------------------------------------------------------------------
class ICADenoiser:
    """FastICA on the concatenated recording + automatic rejection of
       * EOG components : high correlation with the frontal (Fp1/Fp2) low-frequency proxy
       * EMG components : large share of 20-45 Hz power
       * spiky components : very high kurtosis (electrode pops)."""
    name = 'ICA'

    def __init__(self, fs, eog_corr=0.5, emg_ratio=0.30, kurt=12.0, max_remove=6, seed=0):
        self.fs, self.eog_corr, self.emg_ratio, self.kurt = fs, eog_corr, emg_ratio, kurt
        self.max_remove, self.seed = max_remove, seed
        self.last_removed = []

    def denoise(self, X):
        fs = self.fs
        N, C, T = X.shape
        Xf = bandpass(X, 1.0, 45.0, fs)                       # ICA is fitted on 1-45 Hz data (as in Review 1)
        Z = Xf.transpose(1, 0, 2).reshape(C, -1)
        ica = FastICA(n_components=C, whiten='unit-variance', max_iter=600, tol=1e-3, random_state=self.seed)
        S = ica.fit_transform(Z.T).T                          # (K, N*T)
        A = ica.mixing_                                       # (C, K)
        veog = lowpass(Z[FRONT].mean(0), 8.0, fs)
        f, p = welch_psd(S, fs, nperseg=int(fs))
        tot = p[:, (f >= 1) & (f <= 45)].sum(1)
        hf = p[:, (f >= 20) & (f <= 45)].sum(1) / (tot + 1e-12)
        kur = stats.kurtosis(S, axis=1)
        score = []
        for k in range(S.shape[0]):
            r = abs(np.corrcoef(S[k], veog)[0, 1])
            is_eog = r > self.eog_corr
            is_emg = hf[k] > self.emg_ratio
            is_spk = kur[k] > self.kurt
            score.append((is_eog or is_emg or is_spk, max(r, hf[k], kur[k] / 50)))
        bad = [k for k, (b, _) in enumerate(score) if b]
        bad = sorted(bad, key=lambda k: -score[k][1])[:self.max_remove]
        self.last_removed = bad
        S2 = S.copy()
        S2[bad] = 0.0
        Zc = (A @ S2) + ica.mean_[:, None]
        return Zc.reshape(C, N, T).transpose(1, 0, 2)


# ----------------------------------------------------------------------------------
class NLMSDenoiser:
    """Normalised-LMS adaptive noise canceller with *derived* references (no EOG/EMG electrodes in
    the 19-channel montage):  frontal EOG proxy, 50/60 Hz sine+cosine, temporal high-frequency EMG proxy."""
    name = 'NLMS'

    def __init__(self, fs, line_freq=50.0, mu=0.02, taps=4):
        self.fs, self.line, self.mu, self.taps = fs, line_freq, mu, taps

    def _refs(self, x):
        """x: (C,T) continuous -> per-channel reference stack (C,R,T)."""
        C, T = x.shape
        fs = self.fs
        veog_lp = lowpass(x[FRONT].mean(0), 12.0, fs)
        refs = np.zeros((C, 4, T))
        t = np.arange(T) / fs
        for c in range(C):
            if c == FRONT[0]:
                refs[c, 0] = lowpass(x[FRONT[1]], 12.0, fs)       # a channel must not be its own reference
            elif c == FRONT[1]:
                refs[c, 0] = lowpass(x[FRONT[0]], 12.0, fs)
            else:
                refs[c, 0] = veog_lp
        refs[:, 1] = np.sin(2 * np.pi * self.line * t)[None]
        refs[:, 2] = np.cos(2 * np.pi * self.line * t)[None]
        temp = [IDX['T7'], IDX['T8']]
        emg = highpass(x[temp].mean(0), 25.0, fs)
        refs[:, 3] = emg[None]
        refs[temp[0], 3] = highpass(x[temp[1]], 25.0, fs)
        refs[temp[1], 3] = highpass(x[temp[0]], 25.0, fs)
        refs /= (refs.std(-1, keepdims=True) + 1e-12)
        return refs

    def denoise(self, X):
        N, C, T = X.shape
        x = X.transpose(1, 0, 2).reshape(C, -1)               # continuous stream
        R = self._refs(x)                                     # (C,4,NT)
        L = self.taps
        M = R.shape[1] * L
        W = np.zeros((C, M))
        out = np.zeros_like(x)
        U = np.zeros((C, R.shape[1], L))
        for n in range(x.shape[1]):
            U[:, :, 1:] = U[:, :, :-1]
            U[:, :, 0] = R[:, :, n]
            u = U.reshape(C, M)
            e = x[:, n] - np.einsum('cm,cm->c', W, u)
            W += self.mu * e[:, None] * u / (np.einsum('cm,cm->c', u, u)[:, None] + 1e-6)
            out[:, n] = e
        return out.reshape(C, N, T).transpose(1, 0, 2)


# ----------------------------------------------------------------------------------
# Wavelet thresholding with a stationary (undecimated) Daubechies-4 transform, implemented in numpy
# ----------------------------------------------------------------------------------
_DB4 = np.array([0.2303778133088964, 0.7148465705525443, 0.6308807679295904, -0.027983769416983849,
                 -0.18703481171888114, 0.030841381835986965, 0.032883011666982945, -0.010597401784997278])


def _swt_filters(T, J):
    h = _DB4 / np.sqrt(2)
    g = ((-1) ** np.arange(8)) * h[::-1]
    H, G = [], []
    for j in range(J):
        step = 2 ** j
        hj = np.zeros(8 * step)
        gj = np.zeros(8 * step)
        hj[::step] = h
        gj[::step] = g
        H.append(np.fft.rfft(hj, T))
        G.append(np.fft.rfft(gj, T))
    return H, G


def swt(x, J):
    T = x.shape[-1]
    H, G = _swt_filters(T, J)
    a = np.fft.rfft(x, axis=-1)
    details = []
    for j in range(J):
        details.append(np.fft.irfft(G[j] * a, T, axis=-1))
        a = H[j] * a
    return np.fft.irfft(a, T, axis=-1), details


def iswt(approx, details):
    T = approx.shape[-1]
    J = len(details)
    H, G = _swt_filters(T, J)
    a = np.fft.rfft(approx, axis=-1)
    for j in reversed(range(J)):
        d = np.fft.rfft(details[j], axis=-1)
        a = np.conj(H[j]) * a + np.conj(G[j]) * d
    return np.fft.irfft(a, T, axis=-1)


class WaveletDenoiser:
    """Soft thresholding of SWT-db4 detail coefficients; level-wise robust sigma (MAD/0.6745)."""
    name = 'Wavelet'

    def __init__(self, fs, levels=6, k=2.0, mode='level'):
        """mode='level': sigma_j from MAD of every level;  mode='visu': VisuShrink (sigma from the
        finest level only, threshold k*sigma*sqrt(2 ln T)) - the textbook Donoho rule."""
        self.fs, self.J, self.k, self.mode = fs, levels, k, mode

    def denoise(self, X):
        N, C, T = X.shape
        flat = X.reshape(N * C, T)
        a, det = swt(flat, self.J)
        out = []
        mad = lambda d: np.median(np.abs(d - np.median(d, -1, keepdims=True)), -1, keepdims=True) / 0.6745
        sig1 = mad(det[0])
        for d in det:
            if self.mode == 'visu':
                lam = self.k * sig1 * np.sqrt(2 * np.log(T)) / 3.0
            else:
                lam = self.k * mad(d)
            out.append(np.sign(d) * np.maximum(np.abs(d) - lam, 0.0))
        return iswt(a, out).reshape(N, C, T)
