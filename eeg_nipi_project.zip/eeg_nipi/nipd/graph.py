"""Electrode graph for graph-signal-processing (GSP) priors.

Nodes = 19 electrodes, edges = Gaussian-weighted k-nearest-neighbour links
(physiological prior: neighbouring scalp sites share volume-conducted activity).
"""
import numpy as np
from scipy.spatial.distance import cdist
from .config import positions, CH_NAMES


def electrode_graph(names=CH_NAMES, sigma=0.45, k=4):
    P = positions(names)
    D = cdist(P, P)
    A = np.exp(-(D / sigma) ** 2)
    np.fill_diagonal(A, 0.0)
    keep = np.zeros_like(A)
    for i in range(len(P)):
        keep[i, np.argsort(D[i])[1:k + 1]] = 1.0
    keep = np.maximum(keep, keep.T)
    A = A * keep
    L = np.diag(A.sum(1)) - A
    w, U = np.linalg.eigh(L)
    return A, L, w, U


def graph_roughness(X, L):
    """Normalised spatial roughness  tr(X^T L X) / tr(X^T X).  X: (C, T) or (N, C, T).
    Neural activity (volume conducted) is spatially smooth -> low value;
    focal artifacts (EMG, electrode pops) -> high value."""
    X = np.asarray(X)
    if X.ndim == 2:
        X = X[None]
    num = np.einsum('nct,cd,ndt->n', X, L, X)
    den = np.einsum('nct,nct->n', X, X) + 1e-12
    return num / den
