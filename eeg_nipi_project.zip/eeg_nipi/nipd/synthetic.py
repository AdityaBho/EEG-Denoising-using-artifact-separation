"""Physiologically-structured synthetic EEG (ground truth known) + artifact simulators.

Why synthetic?  Real EEG has no clean ground truth.  The standard way to evaluate
denoisers (EEGdenoiseNet etc.) is *semi-synthetic*: take clean EEG, add artifacts of a
known type at a known SNR, and compare the denoised output with the clean original.
This file provides
  1. make_synthetic_eeg()   - stand-in "clean EEG" with rhythms, ERP, phase-coupling,
                              phase-amplitude coupling and a 2-class motor-imagery-like ERD effect
  2. simulate_artifacts()   - EOG / EMG / motion / line-noise simulators with realistic
                              spectral, temporal and spatial signatures.
simulate_artifacts() is also used on REAL clean segments (see data_real.py).
"""
import numpy as np
from scipy import signal
from scipy.spatial.distance import cdist
from .config import CH_NAMES, positions
from .dsp import bandpass, rms

P = positions()
C = len(CH_NAMES)
_D = cdist(P, P)


def _dist_to(center):
    return np.linalg.norm(P - np.asarray(center)[None], axis=1)


# ----------------------------------------------------------------------------------
# Clean neural EEG
# ----------------------------------------------------------------------------------
def _pink(rng, n, T, exponent=1.0):
    w = rng.standard_normal((n, T))
    F = np.fft.rfft(w, axis=-1)
    f = np.fft.rfftfreq(T, 1.0)
    f[0] = f[1]
    F *= (f / f[1]) ** (-exponent / 2.0)
    x = np.fft.irfft(F, T, axis=-1)
    return x / x.std(axis=-1, keepdims=True)


def _narrow(rng, n, T, fs, f0, bw):
    w = rng.standard_normal((n, T))
    x = bandpass(w, max(f0 - bw / 2, 0.5), f0 + bw / 2, fs, order=3)
    return x / (x.std(axis=-1, keepdims=True) + 1e-12)


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def make_synthetic_eeg(n_epochs=120, fs=256.0, dur=4.0, cue=1.0, seed=0):
    """Return dict(X (N,C,T) in uV, y (N,), fs, cue_time).  Class 0/1 ~ left/right imagery."""
    rng = np.random.default_rng(seed)
    pad = int(1.0 * fs)
    T = int(dur * fs)
    Tp = T + 2 * pad
    t = (np.arange(Tp) - pad) / fs
    K = 0.65 * np.eye(C) + 0.35 * (np.exp(-(_D ** 2) / (2 * 0.35 ** 2)) * (1 - np.eye(C)))
    K[:, :] /= K.sum(1, keepdims=True) / 1.0
    X = np.zeros((n_epochs, C, T))
    y = np.arange(n_epochs) % 2
    rng.shuffle(y)

    w_occ = np.exp(-_dist_to((0, -0.8)) / 0.55)
    w_c3 = np.exp(-_dist_to((-0.5, 0)) / 0.30)
    w_c4 = np.exp(-_dist_to((0.5, 0)) / 0.30)
    w_cz = np.exp(-_dist_to((0, 0)) / 0.30)
    w_front = np.exp(-_dist_to((0, 0.55)) / 0.40)
    w_par = np.exp(-_dist_to((0, -0.55)) / 0.40)

    for i in range(n_epochs):
        src = 7.0 * _pink(rng, C, Tp, 1.1)                         # 1/f background
        # slow amplitude modulation (non-stationarity)
        env = 1.0 + 0.25 * _narrow(rng, 1, Tp, fs, 0.4, 0.6)[0]
        # alpha (posterior)
        sh = _narrow(rng, 1, Tp, fs, 10.2, 2.0)[0]
        ind = _narrow(rng, C, Tp, fs, 10.2, 2.0)
        src += 11.0 * w_occ[:, None] * (np.sqrt(.7) * sh + np.sqrt(.3) * ind) * env
        # mu + beta (central) with class dependent ERD after the cue
        ramp = _sigmoid((t - (cue + 0.4)) / 0.15)
        contra_c4 = (y[i] == 0)                                     # left-hand imagery -> ERD over C4
        depth = np.where(contra_c4, 0.70 * w_c4 + 0.10 * w_c3, 0.70 * w_c3 + 0.10 * w_c4)
        depth = np.clip(depth, 0, 0.85)
        erd = 1.0 - depth[:, None] * ramp[None]
        mu_sh = _narrow(rng, 1, Tp, fs, 11.0, 1.6)[0]
        mu_in = _narrow(rng, C, Tp, fs, 11.0, 1.6)
        wmu = np.maximum(np.maximum(w_c3, w_c4), w_cz)
        src += 9.0 * wmu[:, None] * (np.sqrt(.6) * mu_sh + np.sqrt(.4) * mu_in) * erd * env
        be_sh = _narrow(rng, 1, Tp, fs, 21.0, 5.0)[0]
        be_in = _narrow(rng, C, Tp, fs, 21.0, 5.0)
        src += 4.0 * wmu[:, None] * (np.sqrt(.5) * be_sh + np.sqrt(.5) * be_in) * (1 - 0.8 * (1 - erd)) * env
        # frontal-parietal theta that is PHASE-LOCKED (connectivity) with 25 ms lag
        th = _narrow(rng, 1, Tp, fs, 6.0, 2.0)[0]
        lag = int(0.025 * fs)
        th_f = th
        th_p = np.roll(th, lag)
        th_in = _narrow(rng, C, Tp, fs, 6.0, 2.0)
        src += 5.0 * w_front[:, None] * (0.85 * th_f[None] + 0.5 * th_in)
        src += 5.0 * w_par[:, None] * (0.85 * th_p[None] + 0.5 * th_in)
        # theta-phase / gamma-amplitude coupling (cross-frequency) over frontal sites
        ph = np.angle(signal.hilbert(th))
        gam = _narrow(rng, C, Tp, fs, 37.0, 12.0)
        src += 1.6 * w_front[:, None] * gam * (1.0 + 0.9 * np.cos(ph))[None]
        # ERP (phase-locked to the cue): N1 @100 ms (posterior, neg), P3 @320 ms (parieto-central, pos)
        a1, a3 = rng.uniform(0.8, 1.2, 2)
        l1, l3 = 0.10 + rng.normal(0, .008), 0.32 + rng.normal(0, .012)
        g = lambda t0, s: np.exp(-0.5 * ((t - cue - t0) / s) ** 2)
        p3gain = 1.0 if y[i] == 0 else 1.3
        src += (-4.5 * a1 * g(l1, 0.025))[None] * w_occ[:, None]
        src += (6.0 * a3 * p3gain * g(l3, 0.055))[None] * np.maximum(w_par, w_cz)[:, None]
        x = K @ src
        x = bandpass(x, 1.0, 45.0, fs)
        X[i] = x[:, pad:pad + T]

    X *= 12.0 / rms(X)          # overall ~12 uV RMS
    return dict(X=X, y=y, fs=fs, cue_time=cue)


# ----------------------------------------------------------------------------------
# Artifact simulators (unit-scale; scaled to target SNR afterwards)
# ----------------------------------------------------------------------------------
def _alpha_fn(t, t0, tau):
    u = np.clip(t - t0, 0, None)
    return (u / tau) * np.exp(1 - u / tau)          # asymmetric blink shape (peak = 1)


def sim_eog(N, T, fs, rng):
    """Blinks (frontal, vertical dipole) + lateral saccades (F7/F8 antisymmetric)."""
    t = np.arange(T) / fs
    dur = T / fs
    pv = np.exp(-_dist_to((0, 1.0)) / 0.8)
    pv /= pv.max()
    ph = (P[:, 0] / 0.95) * np.exp(-np.abs(P[:, 1] - 0.6) / 0.8)
    out = np.zeros((N, C, T))
    for i in range(N):
        for _ in range(rng.integers(1, 4)):
            w = _alpha_fn(t, rng.uniform(0.2, dur - 0.9), rng.uniform(0.06, 0.12)) * rng.uniform(0.7, 1.3)
            out[i] += pv[:, None] * w[None]
        if rng.random() < 0.5:
            t0 = rng.uniform(0.3, dur - 1.2)
            d = rng.uniform(0.3, 0.8)
            s = _sigmoid((t - t0) / 0.02) - _sigmoid((t - t0 - d) / 0.02)
            out[i] += rng.choice([-1, 1]) * 0.6 * ph[:, None] * s[None]
    return out


def sim_emg(N, T, fs, rng):
    """Broadband (20-~110 Hz) muscle bursts, spatially focal (temporalis L/R, frontalis)."""
    centers = [(-0.95, 0.10), (0.95, 0.10), (0.0, 0.85)]
    hi = min(110.0, 0.9 * fs / 2)
    out = np.zeros((N, C, T))
    for i in range(N):
        for _ in range(rng.integers(1, 4)):
            ctr = centers[rng.integers(len(centers))]
            w = np.exp(-_dist_to(ctr) / 0.45)
            L = int(rng.uniform(0.3, 1.2) * fs)
            t0 = rng.integers(0, T - L)
            env = np.zeros(T)
            env[t0:t0 + L] = np.hanning(L)
            noise = bandpass(rng.standard_normal((C, T)), 20.0, hi, fs, order=3)
            out[i] += w[:, None] * noise * env[None] * rng.uniform(0.7, 1.3)
    return out


def sim_motion(N, T, fs, rng):
    """Electrode 'pops' / cable-movement: abrupt step with exponential recovery on 1-2 electrodes."""
    t = np.arange(T) / fs
    dur = T / fs
    out = np.zeros((N, C, T))
    for i in range(N):
        for _ in range(rng.integers(1, 4)):
            ch = rng.integers(C)
            t0 = rng.uniform(0.1, dur - 1.0)
            tau = rng.uniform(0.04, 0.25)
            w = (t >= t0) * np.exp(-(t - t0) / tau) * rng.choice([-1, 1]) * rng.uniform(0.7, 1.3)
            out[i, ch] += w
            if rng.random() < 0.3:                      # neighbouring electrode shares part of the movement
                nb = np.argsort(_D[ch])[1]
                out[i, nb] += 0.4 * w
    return out


def sim_line(N, T, fs, rng, line_freq=50.0):
    t = np.arange(T) / fs
    out = np.zeros((N, C, T))
    for i in range(N):
        gain = rng.normal(1.0, 0.2, C)
        ph0 = rng.uniform(0, 2 * np.pi)
        ph = ph0 + rng.normal(0, 0.15, C)
        f = line_freq + rng.normal(0, 0.05)
        out[i] = gain[:, None] * np.sin(2 * np.pi * f * t[None] + ph[:, None])
        if 2 * f < 0.95 * fs / 2:
            out[i] += 0.25 * gain[:, None] * np.sin(2 * np.pi * 2 * f * t[None] + 2 * ph[:, None])
    return out


SIMS = {'eog': sim_eog, 'emg': sim_emg, 'motion': sim_motion}


def scale_to_snr(clean, art, snr_db):
    """SNR (dB) = 20 log10( RMS(clean) / RMS(artifact) ), per epoch (EEGdenoiseNet convention)."""
    rc = rms(clean, axis=(1, 2), keepdims=True)
    ra = rms(art, axis=(1, 2), keepdims=True) + 1e-12
    return art * rc / (ra * 10 ** (snr_db / 20.0))


def simulate_artifacts(clean, fs, kind, snr_db, seed=0, line_freq=50.0, mixed_offset=3.0):
    """kind in {'eog','emg','motion','line','mixed'}.  Returns (contaminated, artifact)."""
    rng = np.random.default_rng(seed)
    N, _, T = clean.shape
    kinds = ['eog', 'emg', 'motion', 'line'] if kind == 'mixed' else [kind]
    off = mixed_offset if kind == 'mixed' else 0.0
    art = np.zeros_like(clean)
    for k in kinds:
        a = sim_line(N, T, fs, rng, line_freq) if k == 'line' else SIMS[k](N, T, fs, rng)
        art += scale_to_snr(clean, a, snr_db + off)
    return clean + art, art
