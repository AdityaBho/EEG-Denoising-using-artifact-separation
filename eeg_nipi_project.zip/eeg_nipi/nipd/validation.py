"""Does NIPI measure something that RMSE / correlation do not?   (metric validation, Stage 3)

We apply CONTROLLED, known degradations to clean EEG - exactly the kinds of damage a denoiser can
inflict on neural information - and compare conventional metrics with NIPI.
"""
import numpy as np
import pandas as pd
from .dsp import bandpass, eval_filter
from .metrics import rrmse, cc
from .nipi import NIPIReference, gaussian_mi_coefficient
from .config import CH_NAMES
from .graph import electrode_graph

IDX = {c: i for i, c in enumerate(CH_NAMES)}


def degradations(X, y, fs, cue, seed=0):
    rng = np.random.default_rng(seed)
    N, C, T = X.shape
    A, L, _, _ = electrode_graph()
    An = A / A.sum(1, keepdims=True)
    out = {}

    def white(snr):
        n = bandpass(rng.standard_normal(X.shape), 1, 45, fs)
        return X + n * np.sqrt((X ** 2).mean()) / np.sqrt((n ** 2).mean()) / 10 ** (snr / 20)

    for s in (20, 10, 5):
        out[f'additive noise {s} dB'] = white(s)
    out['amplitude x0.7'] = 0.7 * X
    out['alpha band removed (8-13 Hz)'] = X - bandpass(X, 8, 13, fs)
    out['beta band removed (13-30 Hz)'] = X - bandpass(X, 13, 30, fs)
    out['30 ms time shift (phase distortion)'] = np.roll(X, int(0.03 * fs), axis=-1)
    out['spatial smoothing (graph low-pass)'] = np.einsum('cd,ndt->nct', 0.5 * np.eye(C) + 0.5 * An, X)
    # remove class-averaged evoked response (ERP wiped out, ongoing EEG intact)
    i0 = int(cue * fs)
    Xe = X.copy()
    for k in np.unique(y):
        m = y == k
        erp = X[m].mean(0)
        erp_loc = np.zeros_like(erp)
        erp_loc[:, i0:] = erp[:, i0:]
        Xe[m] -= erp_loc
    out['evoked response (ERP) removed'] = Xe
    # per-trial normalisation of mu/beta power (a common 'denoising' side effect): the task-related
    # power difference between trials/classes is erased while phase / spectrum shape stay intact
    xb = bandpass(X, 8, 30, fs)
    pw = xb.var(-1)
    scale = np.sqrt(pw.mean(0, keepdims=True) / (pw + 1e-12))
    out['per-trial mu/beta power normalisation'] = X - xb + xb * scale[..., None]
    return out


def run_validation(clean, y, fs, cue, cfg=None):
    ref = eval_filter(clean, fs)
    nref = NIPIReference(ref, fs, y, cue, cfg)
    rows = []
    for name, d in degradations(ref, y, fs, cue).items():
        sc = nref.score(d)
        r = dict(degradation=name, rRMSE=rrmse(ref, d), CC=cc(ref, d), MI_IC=gaussian_mi_coefficient(ref, d, fs))
        r.update({k: sc[k] for k in ('NIPI', 'S', 'P', 'C', 'E', 'H', 'D') if k in sc})
        rows.append(r)
    return pd.DataFrame(rows)
