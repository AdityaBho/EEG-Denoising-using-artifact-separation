"""NIPI feedback loop  (Review-1 slide: 'NIPI shows where information is lost; lambda is adjusted
and the method is retrained').

Conventional objective      :  min  RER(theta)                       (artifact / error energy only)
Proposed objective          :  min  RER(theta) + lambda * (1 - NIPI(theta))

theta = NIPD hyper-parameters (strengths g_k, detection thresholds, spectral floor, graph weight).
The search is gradient-free (random search + local refinement) because NIPI contains Hilbert
transforms, cross-validated classifiers and arg-max latencies.
"""
import time
import numpy as np
from dataclasses import fields

from .dsp import eval_filter
from .metrics import rer
from .nipd import NIPD, NIPDParams
from .nipi import NIPIReference, NIPIConfig
from .synthetic import simulate_artifacts

SPACE = dict(g_line=(0.6, 1.1), g_eog=(0.4, 1.1), g_motion=(0.4, 1.1), g_emg=(0.4, 1.1),
             eog_k=(3.0, 8.0), motion_k=(4.0, 10.0), emg_alpha=(0.4, 2.0), emg_beta=(0.02, 0.40),
             graph_mu=(0.0, 10.0))


def _sample(rng, base=None, scale=1.0):
    d = {}
    for k, (lo, hi) in SPACE.items():
        if base is None:
            d[k] = rng.uniform(lo, hi)
        else:
            d[k] = float(np.clip(base[k] + rng.normal(0, 0.15 * scale * (hi - lo)), lo, hi))
    return d


def tune_nipd(model_template, clean_tune, y_tune, fs, cue, line_freq, lam=1.0, n_random=24, n_local=24,
              kinds=('eog', 'emg', 'motion', 'mixed'), snr=0.0, seed=0, verbose=True):
    """model_template: a fitted NIPD (rho / floor are re-used).  Returns (best NIPDParams, history)."""
    rng = np.random.default_rng(seed)
    ref = eval_filter(clean_tune, fs)
    nref = NIPIReference(ref, fs, y_tune, cue)
    conds = []
    for i, k in enumerate(kinds):
        c, _ = simulate_artifacts(clean_tune, fs, k, snr, seed=200 + i, line_freq=line_freq)
        conds.append((c, eval_filter(c, fs)))

    def objective(params):
        m = NIPD(fs, line_freq, params)
        m.rho, m.hf_floor, m.hf_band = model_template.rho, model_template.hf_floor, model_template.hf_band
        r, n = [], []
        for c, cf in conds:
            den = eval_filter(m.denoise(c), fs)
            r.append(rer(ref, cf, den))
            n.append(nref.score(den)['NIPI'])
        return float(np.mean(r) + lam * (1 - np.mean(n))), float(np.mean(r)), float(np.mean(n))

    hist = []
    t0 = time.time()
    cand = [NIPDParams().as_dict()] + [_sample(rng) for _ in range(n_random)]
    best, bestJ = None, np.inf
    for i, d in enumerate(cand):
        J, R, N = objective(NIPDParams(**d))
        hist.append(dict(stage='random', J=J, RER=R, NIPI=N, **d))
        if J < bestJ:
            best, bestJ = d, J
        if verbose and (i % 8 == 0):
            print(f'    [lam={lam}] eval {i + 1}/{len(cand)}  best J={bestJ:.4f}  ({time.time() - t0:.0f}s)', flush=True)
    for j in range(n_local):
        d = _sample(rng, best, scale=1.0 - 0.5 * j / max(1, n_local))
        J, R, N = objective(NIPDParams(**d))
        hist.append(dict(stage='local', J=J, RER=R, NIPI=N, **d))
        if J < bestJ:
            best, bestJ = d, J
    if verbose:
        print(f'    [lam={lam}] done: J={bestJ:.4f}  ({time.time() - t0:.0f}s)', flush=True)
    return NIPDParams(**best), hist
