"""Build CLEAN REFERENCE epochs (19 ch, 128 Hz, 4 s) from your real EDF datasets.  (needs: pip install mne)
  python data_real.py --edf S001R04.edf S001R08.edf --out data/mi_clean.npz --mode mi      # PhysioNet MI: T1/T2 events, stim at t=1 s
  python data_real.py --edf chb.edf --out data/siena_clean.npz --mode continuous            # no labels -> 'task'/'erp' skipped
Real EEG is never perfectly clean: we KEEP only artifact-free epochs (peak-to-peak < 100 uV, low HF/EMG power) and treat them
as ground truth; artifacts are then ADDED synthetically (semi-synthetic protocol, as in EEGdenoiseNet)."""
import argparse, numpy as np, mne
from eegnipi.montage import CH
ALIAS = {'T7': 'T3', 'T8': 'T4', 'P7': 'T5', 'P8': 'T6'}
def norm(n): n = n.upper().replace('EEG', '').replace('-REF', '').replace('-LE', '').replace('.', '').strip(); return {k.upper(): v for k, v in ALIAS.items()}.get(n, n)

def load(edf, mode, fs=128, dur=4.0, stim=1.0):
    raw = mne.io.read_raw_edf(edf, preload=True, verbose='error')
    names = {c: norm(c) for c in raw.ch_names}; want = [c.upper() for c in CH]
    pick = [next(k for k, v in names.items() if v == w) for w in want]            # raises if a channel is missing -> check names
    raw.pick(pick); raw.reorder_channels(pick)
    raw.filter(1, 45, verbose='error'); raw.notch_filter([50, 60], verbose='error') if raw.info['sfreq'] > 130 else None
    raw.resample(fs, verbose='error'); T = int(fs * dur); X, y = [], []
    if mode == 'mi':                                              # T1 = left(imagined) fist, T2 = right ; stim at 1 s in the window
        ann = raw.annotations
        for o, d in zip(ann.onset, ann.description):
            if d in ('T1', 'T2'):
                s = int((o - stim) * fs)
                if s >= 0 and s + T <= raw.n_times: X.append(raw.get_data(start=s, stop=s + T) * 1e6); y.append(int(d == 'T2'))
    else:
        D = raw.get_data() * 1e6
        for s in range(0, D.shape[1] - T, T): X.append(D[:, s:s + T]); y.append(0)
    return np.array(X, np.float32), np.array(y)

def is_clean(e, fs=128):
    from scipy.signal import welch
    f, P = welch(e, fs, nperseg=128, axis=-1); hf = P[:, f > 25].sum(1) / P.sum(1)
    return (np.ptp(e, axis=-1).max() < 100) and (hf.max() < 0.15)

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--edf', nargs='+'); p.add_argument('--out'); p.add_argument('--mode', default='mi'); a = p.parse_args()
    XS, YS = zip(*[load(f, a.mode) for f in a.edf]); X, y = np.concatenate(XS), np.concatenate(YS)
    keep = np.array([is_clean(e) for e in X]); X, y = X[keep], y[keep]
    print(f'kept {keep.sum()}/{len(keep)} artifact-free epochs; class counts: {np.bincount(y)}')
    np.savez(a.out, X=X, y=y, fs=128)
