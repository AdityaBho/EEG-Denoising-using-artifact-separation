#!/usr/bin/env python
"""Neural Stage 2:  train NIPD-Net with (a) conventional MSE objective and (b) NIPI-surrogate objective,
then benchmark both against the classical methods + NIPD.  Needs PyTorch.

    python run_nn.py                              # synthetic data, 40 epochs  (CPU: ~15-25 min)
    python run_nn.py --epochs 5 --quick           # smoke run
    python run_nn.py --dataset eegmmidb --path D:/data/eegmmidb --line 60
"""
import argparse, os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nipd.synthetic import make_synthetic_eeg, simulate_artifacts
from nipd.dsp import eval_filter
from nipd.pipeline import run_pipeline
from nipd import nn as nipnn

ap = argparse.ArgumentParser()
ap.add_argument('--dataset', default='synthetic', choices=['synthetic', 'eegmmidb', 'siena'])
ap.add_argument('--path', default=None)
ap.add_argument('--subjects', nargs='+', default=['S001', 'S002', 'S003'])
ap.add_argument('--line', type=float, default=50.0)
ap.add_argument('--fs', type=float, default=256.0)
ap.add_argument('--epochs', type=int, default=40)
ap.add_argument('--variants', type=int, default=20, help='random artifact/SNR variants per clean epoch')
ap.add_argument('--quick', action='store_true')
ap.add_argument('--out', default=None)
a = ap.parse_args()

if a.dataset == 'synthetic':
    d = make_synthetic_eeg(n_epochs=100 if a.quick else 200, fs=a.fs)
    X, y, fs, cue = d['X'], d['y'], a.fs, d['cue_time']
else:
    from nipd import data_real as dr
    X, y, fs, cue = (dr.load_eegmmidb(a.path, tuple(a.subjects), line=a.line) if a.dataset == 'eegmmidb'
                     else dr.load_siena(a.path, line=a.line))
    idx = np.random.default_rng(0).permutation(len(X))
    X, y = X[idx], (None if y is None else y[idx])

# SAME split as pipeline.run_pipeline (train 35 % / tune 25 % / test 40 %): the network never sees test epochs
N = len(X)
n_fit = int(0.35 * N) + int(0.25 * N)
Xfit = X[:n_fit]
rng = np.random.default_rng(0)
kinds = ['eog', 'emg', 'motion', 'line', 'mixed']
n_var = 4 if a.quick else a.variants
Xc, Xr = [], []
for v in range(n_var):
    kind, snr = kinds[rng.integers(len(kinds))], rng.uniform(-6, 4)
    cont, _ = simulate_artifacts(Xfit, fs, kind, snr, seed=1000 + v, line_freq=a.line)
    Xc.append(cont); Xr.append(eval_filter(Xfit, fs))
Xc, Xr = np.concatenate(Xc), np.concatenate(Xr)
print(f'[NN] training pairs: {Xc.shape}', flush=True)

ep = 3 if a.quick else a.epochs
m_mse = nipnn.train_nipdnet(Xc, Xr, fs, objective='mse', epochs=ep)
m_nipi = nipnn.train_nipdnet(Xc, Xr, fs, objective='nipi', epochs=ep)
extra = {'DAE-Net (MSE loss)': nipnn.NNDenoiser(m_mse, 'DAE-Net (MSE loss)'),
         'NIPD-Net (NIPI loss)': nipnn.NNDenoiser(m_nipi, 'NIPD-Net (NIPI loss)')}
out = a.out or f'results/nn_{a.dataset}'
run_pipeline(X, y, fs, cue, a.line, out, quick=a.quick, tag=f'(+ neural Stage 2, {a.dataset})', extra_methods=extra)
