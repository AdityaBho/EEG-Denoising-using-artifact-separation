"""Run this FIRST on your machine:  python tests/test_torch_smoke.py
Checks shapes, differentiability of every NIPI-surrogate term, and that a few optimiser steps lower the loss."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import numpy as np
import torch
from nipd.nn import NIPDNet, NIPILoss, train_nipdnet, NNDenoiser
from nipd.synthetic import make_synthetic_eeg, simulate_artifacts
from nipd.dsp import eval_filter

fs = 256.0
d = make_synthetic_eeg(n_epochs=16, fs=fs, seed=0)
ref = eval_filter(d['X'], fs)
cont, _ = simulate_artifacts(d['X'], fs, 'mixed', 0.0, seed=1)

net = NIPDNet()
x = torch.tensor(cont[:4], dtype=torch.float32)
y = net(x)
assert y.shape == x.shape, y.shape
print('forward OK', tuple(y.shape), ' parameters:', sum(p.numel() for p in net.parameters()))

crit = NIPILoss(fs, w_mi=0.2)
loss, parts = crit(y, torch.tensor(ref[:4], dtype=torch.float32))
loss.backward()
assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in net.parameters() if p.requires_grad), 'bad gradients'
print('loss terms:', {k: round(v, 4) for k, v in parts.items()})
print('backward OK (all gradients finite)')

m = train_nipdnet(np.concatenate([cont] * 2), np.concatenate([ref] * 2), fs, objective='nipi', epochs=3, batch=8, verbose=True)
den = NNDenoiser(m, 'smoke').denoise(cont[:4])
assert den.shape == cont[:4].shape and np.isfinite(den).all()
print('SMOKE TEST PASSED')
