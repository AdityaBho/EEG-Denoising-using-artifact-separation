"""Sanity/validity tests of NIPI (run: python tests/test_nipi_properties.py). These are the 'axioms' to show the panel."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import numpy as np
from scipy.signal import butter, sosfiltfilt
from eegnipi.simulate import make_clean
from eegnipi.artifacts import contaminate
from eegnipi.nipi import nipi
fs = 128
x, y = make_clean(n=120, fs=fs, seed=3)

# A1 identity -> 1
r = nipi(x, x.copy(), y, fs); assert r['NIPI'] > 0.999, r
# A2 monotonic: more noise -> lower NIPI
v = [nipi(x, contaminate(x, 'mixed', s, fs)[0], y, fs)['NIPI'] for s in (10, 5, 0, -5)]
assert all(a > b for a, b in zip(v, v[1:])), v
# A3 over-smoothing (low-pass 8 Hz) must be punished although it looks "clean"
lp = sosfiltfilt(butter(4, 8, fs=fs, output='sos'), x, axis=-1).astype(np.float32)
assert nipi(x, lp, y, fs)['NIPI'] < 0.6
# A4 amplitude shrinkage (0.5x) is punished (spectral/ERP) but phase is untouched
sh = nipi(x, 0.5 * x, y, fs); assert sh['phase'] > 0.95 and sh['spectral'] < 0.6 and sh['erp'] < 0.8, sh
# A5 time-shift of 40 ms destroys phase/ERP much more than amplitude-preserving spectrum
sf = nipi(x, np.roll(x, int(0.04 * fs), -1), y, fs); assert sf['phase'] < sh['phase'] and sf['spectral'] > 0.95, sf
# A6 label shuffle -> task component should drop on a destroyed signal (white noise)
wn = nipi(x, np.random.default_rng(0).standard_normal(x.shape).astype(np.float32) * x.std(), y, fs)
assert wn['task'] < 0.5 and wn['NIPI'] < 0.3, wn
print('ALL NIPI PROPERTY TESTS PASSED', [round(a, 3) for a in v])
