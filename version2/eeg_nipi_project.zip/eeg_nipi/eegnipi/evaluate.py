import numpy as np, pandas as pd, time
from .artifacts import contaminate
from .nipi import nipi, artifact_suppression, joint_score, rank_stability

def evaluate_methods(clean, labels, methods, fs, kind='mixed', snr_db=0, seed=1, verbose=True):
    noisy, art, refs = contaminate(clean, kind, snr_db, fs, seed)
    rows, comp = [], {}
    for name, fn in methods.items():
        t0 = time.time(); den = fn(noisy, refs, fs)
        s = artifact_suppression(clean, noisy, den); n = nipi(clean, den, labels, fs)
        comp[name] = n
        rows.append(dict(method=name, kind=kind, snr_db=snr_db, **s, NIPI=n['NIPI'], Joint=joint_score(s['ARR'], n['NIPI']),
                         **{k: n[k] for k in ('spectral','phase','connect','geometry','erp','entropy','task')}, sec=time.time() - t0))
        if verbose: print(f"  {name:14s} ARR={s['ARR']:.2f} CC={s['CC']:.2f} NIPI={n['NIPI']:.3f} Joint={rows[-1]['Joint']:.3f}")
    return pd.DataFrame(rows), comp
