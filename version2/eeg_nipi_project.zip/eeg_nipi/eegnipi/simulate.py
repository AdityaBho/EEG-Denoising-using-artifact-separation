"""Physiologically-structured synthetic EEG (for tests/demo ONLY; real data = data_real.py).
Contains: 1/f background, spatially mixed sources, alpha/beta rhythms with cross-channel phase
coupling, mu-rhythm ERD (class dependent, C3/C4), stimulus-locked ERP at t=1 s (class dependent amplitude)."""
import numpy as np
from scipy.signal import butter, sosfiltfilt
from .montage import XY, norm_adjacency

def _pink(rng, n, C, T, fs):
    f = np.fft.rfftfreq(T, 1 / fs); f[0] = f[1]
    X = (rng.standard_normal((n, C, f.size)) + 1j * rng.standard_normal((n, C, f.size))) / f
    x = np.fft.irfft(X, T, axis=-1); return x / x.std()

def bandpass(x, lo, hi, fs, order=4):
    sos = butter(order, [lo, hi], btype='band', fs=fs, output='sos'); return sosfiltfilt(sos, x, axis=-1)

def make_clean(n=240, fs=128, dur=4.0, seed=0):
    rng = np.random.default_rng(seed); T = int(fs * dur); C = len(XY); t = np.arange(T) / fs
    y = np.tile([0, 1], n // 2); rng.shuffle(y)
    M = np.linalg.matrix_power(norm_adjacency(0.6), 2)            # volume-conduction-like spatial mixing
    x = 10 * np.einsum('ij,njt->nit', M, _pink(rng, n, C, T, fs))
    post = np.exp(-((XY[:, 1] + 0.6) ** 2) / 0.3)                 # posterior weighting (alpha)
    cen = np.exp(-(XY[:, 1] ** 2) / 0.15)                         # central weighting (mu/beta)
    for i in range(n):
        ph = rng.uniform(0, 2 * np.pi)                            # shared alpha driver -> phase coupling
        for c in range(C):
            a = 8 * post[c] * np.sin(2 * np.pi * 10 * t + ph + 0.25 * rng.standard_normal())
            b = 3 * cen[c] * np.sin(2 * np.pi * 21 * t + rng.uniform(0, 6.28))
            erd = np.ones(T)                                      # mu ERD after t = 1 s, contralateral
            contra = (XY[c, 0] > 0.2 and y[i] == 0) or (XY[c, 0] < -0.2 and y[i] == 1)
            if contra: erd[t > 1.0] = 0.25
            mu = 7 * cen[c] * erd * np.sin(2 * np.pi * 11 * t + rng.uniform(0, 6.28))
            x[i, c] += a + b + mu
        erp = np.exp(-((t - 1.3) ** 2) / (2 * 0.06 ** 2)) - 0.6 * np.exp(-((t - 1.1) ** 2) / (2 * 0.03 ** 2))
        amp = 9.0 if y[i] == 0 else 5.0
        x[i] += amp * erp[None] * (np.exp(-((XY[:, 1]) ** 2) / 0.4))[:, None]
    return bandpass(x, 1, 45, fs).astype(np.float32), y
