"""Training objective  L = L_rec + sum_k lambda_k * L_k   ("Minimise artifact energy + maximise neural-information preservation").
Each L_k is a DIFFERENTIABLE surrogate of one NIPI component; lambdas are updated by the NIPI feedback loop (train.py)."""
import numpy as np, torch, torch.nn.functional as F
from .montage import laplacian
BANDS = [(1, 4), (4, 8), (8, 13), (13, 30), (30, 45)]
KEYS = ['rec', 'spec', 'phase', 'conn', 'cov', 'graph', 'info', 'type']

def _fft(x): return torch.fft.rfft(x, dim=-1)
def _freqs(T, fs): return torch.fft.rfftfreq(T, 1 / fs).to('cpu')

def spectral_loss(y, x, fs):                                  # <-> NIPI.spectral : log band-power match
    Y, X = _fft(y).abs() ** 2, _fft(x).abs() ** 2; f = _freqs(y.shape[-1], fs); l = 0
    for lo, hi in BANDS:
        m = ((f >= lo) & (f < hi)).to(y.device); l = l + (torch.log(Y[..., m].mean(-1) + 1e-8) - torch.log(X[..., m].mean(-1) + 1e-8)).abs().mean()
    return l / len(BANDS)

def phase_loss(y, x, fs):                                     # <-> NIPI.phase : 1 - cos(phase diff) weighted by clean power
    Y, X = _fft(y), _fft(x); f = _freqs(y.shape[-1], fs); m = ((f >= 1) & (f <= 45)).to(y.device)
    cosd = (Y * X.conj()).real / (Y.abs() * X.abs() + 1e-8); w = X.abs() ** 2
    return (((1 - cosd) * w)[..., m].sum(-1) / (w[..., m].sum(-1) + 1e-8)).mean()

def _band_sig(x, fs, lo, hi):
    X = _fft(x); f = _freqs(x.shape[-1], fs); m = ((f >= lo) & (f < hi)).to(x.device)
    return torch.fft.irfft(X * m.float(), n=x.shape[-1], dim=-1)

def _corr(x):
    x = x - x.mean(-1, keepdim=True); x = x / (x.norm(dim=-1, keepdim=True) + 1e-8); return x @ x.transpose(1, 2)

def connectivity_loss(y, x, fs):                              # <-> NIPI.connect / phase PLV : band channel-correlation matrices
    l = 0
    for lo, hi in [(4, 8), (8, 13), (13, 30)]:
        cy, cx = _corr(_band_sig(y, fs, lo, hi)), _corr(_band_sig(x, fs, lo, hi))
        l = l + (cy - cx).flatten(1).norm(dim=1).div(cx.flatten(1).norm(dim=1) + 1e-8).mean()
    return l / 3

def covariance_loss(y, x):                                    # <-> NIPI.geometry (Euclidean surrogate of the Riemannian distance)
    cov = lambda a: (a - a.mean(-1, keepdim=True)) @ (a - a.mean(-1, keepdim=True)).transpose(1, 2) / a.shape[-1]
    cy, cx = cov(y), cov(x); return ((cy - cx).flatten(1).norm(dim=1) / (cx.flatten(1).norm(dim=1) + 1e-8)).mean()

def graph_loss(y, x, L):                                      # GSP prior: graph-smoothness (Dirichlet energy) must match clean
    e = lambda a: torch.einsum('bct,cd,bdt->b', a, L, a) / (a.pow(2).sum((1, 2)) + 1e-8)
    return (torch.log(e(y) + 1e-8) - torch.log(e(x) + 1e-8)).abs().mean()

def infonce(zy, zx, tau=0.1):                                 # I(clean ; denoised) >= log(B) - L_NCE   (InfoNCE bound)
    lg = zy @ zx.T / tau; t = torch.arange(len(zy), device=zy.device)
    return 0.5 * (F.cross_entropy(lg, t) + F.cross_entropy(lg.T, t))

def total_loss(model_out, clean, types, proj, lam, fs, L):
    y, n_hat, logits = model_out; d = {}
    d['rec'] = F.l1_loss(y, clean)
    d['spec'] = spectral_loss(y, clean, fs); d['phase'] = phase_loss(y, clean, fs); d['conn'] = connectivity_loss(y, clean, fs)
    d['cov'] = covariance_loss(y, clean); d['graph'] = graph_loss(y, clean, L)
    d['info'] = infonce(proj(y), proj(clean)); d['type'] = F.binary_cross_entropy_with_logits(logits, types)
    tot = sum(lam[k] * v for k, v in d.items()); return tot, {k: float(v) for k, v in d.items()}
