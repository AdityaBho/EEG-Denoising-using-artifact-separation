"""NIPD-Net: graph-aware, attention-guided 1-D U-Net that predicts the ARTIFACT and subtracts it (y = x - n_hat).
Stage 1 (artifact characterisation): auxiliary head classifies artifact types (EOG/EMG/motion/line) + graph prior.
Stage 2 (neural-dynamics preservation): SE channel attention + temporal self-attention + info/NIPI-aware losses (losses.py).
NOTE: written for PyTorch >= 2.0; T must be divisible by 8 (e.g. 512)."""
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from .montage import norm_adjacency

def blk(i, o, k=7, s=1):
    return nn.Sequential(nn.Conv1d(i, o, k, s, k // 2), nn.GroupNorm(8, o), nn.GELU())

class SE(nn.Module):                                    # channel (feature) attention
    def __init__(s, c, r=8):
        super().__init__(); s.f = nn.Sequential(nn.Linear(c, c // r), nn.GELU(), nn.Linear(c // r, c), nn.Sigmoid())
    def forward(s, x): return x * s.f(x.mean(-1))[..., None]

class NIPDNet(nn.Module):
    def __init__(s, C=19, base=48, n_types=4, heads=4):
        super().__init__()
        s.register_buffer('A', torch.tensor(norm_adjacency(), dtype=torch.float32))      # graph prior (electrode graph)
        s.inp = nn.Sequential(blk(3 * C, base), blk(base, base))                         # [x, Ax, A^2 x] (graph features)
        s.d1 = nn.Sequential(blk(base, 2 * base, s=2), blk(2 * base, 2 * base))
        s.d2 = nn.Sequential(blk(2 * base, 4 * base, s=2), blk(4 * base, 4 * base))
        s.d3 = nn.Sequential(blk(4 * base, 4 * base, s=2), blk(4 * base, 4 * base))
        s.se = SE(4 * base); s.att = nn.MultiheadAttention(4 * base, heads, batch_first=True); s.ln = nn.LayerNorm(4 * base)
        s.u2 = blk(8 * base, 4 * base); s.u1 = blk(6 * base, 2 * base); s.u0 = blk(3 * base, base)
        s.out = nn.Conv1d(base, C, 1)
        s.cls = nn.Linear(4 * base, n_types)                                              # artifact-type head (Stage 1)
    def forward(s, x):
        g = torch.cat([x, torch.einsum('ij,bjt->bit', s.A, x), torch.einsum('ij,bjt->bit', s.A @ s.A, x)], 1)
        e0 = s.inp(g); e1 = s.d1(e0); e2 = s.d2(e1); b = s.se(s.d3(e2))
        z = b.transpose(1, 2); z = s.ln(z + s.att(z, z, z, need_weights=False)[0]); b = z.transpose(1, 2)
        up = lambda a, ref: F.interpolate(a, size=ref.shape[-1], mode='linear', align_corners=False)
        d2 = s.u2(torch.cat([up(b, e2), e2], 1)); d1 = s.u1(torch.cat([up(d2, e1), e1], 1)); d0 = s.u0(torch.cat([up(d1, e0), e0], 1))
        n_hat = s.out(d0)
        return x - n_hat, n_hat, s.cls(b.mean(-1))                                        # denoised, artifact estimate, type logits

class Projector(nn.Module):                              # embedding used by InfoNCE (mutual-information lower bound)
    def __init__(s, C=19, d=128):
        super().__init__(); s.net = nn.Sequential(blk(C, 64, 7, 2), blk(64, 128, 7, 2), blk(128, 128, 7, 2)); s.fc = nn.Linear(128, d)
    def forward(s, x): return F.normalize(s.fc(s.net(x).mean(-1)), dim=-1)
