"""19-channel 10-20 montage (approx. 2-D scalp coordinates) + electrode graph."""
import numpy as np

CH = ['Fp1','Fp2','F7','F3','Fz','F4','F8','T3','C3','Cz','C4','T4',
      'T5','P3','Pz','P4','T6','O1','O2']
XY = np.array([(-.31,.95),(.31,.95),(-.81,.59),(-.45,.55),(0,.5),(.45,.55),(.81,.59),
               (-1,0),(-.5,0),(0,0),(.5,0),(1,0),
               (-.81,-.59),(-.45,-.55),(0,-.5),(.45,-.55),(.81,-.59),(-.31,-.95),(.31,-.95)])
IDX = {c: i for i, c in enumerate(CH)}

def adjacency(sigma=0.5):
    """Gaussian-distance electrode graph (graph prior for Stage 1/2 and GSP)."""
    d2 = ((XY[:, None] - XY[None]) ** 2).sum(-1)
    A = np.exp(-d2 / sigma ** 2); np.fill_diagonal(A, 0)
    return A

def norm_adjacency(sigma=0.5):
    A = adjacency(sigma) + np.eye(len(CH))
    d = A.sum(1); return A / np.sqrt(d[:, None] * d[None])      # D^-1/2 (A+I) D^-1/2

def laplacian(sigma=0.5):
    A = adjacency(sigma); return np.diag(A.sum(1)) - A
