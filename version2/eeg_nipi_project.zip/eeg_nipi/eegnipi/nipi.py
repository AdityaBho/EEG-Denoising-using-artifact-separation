"""
Neural Information Preservation Index (NIPI)
============================================
Compares a DENOISED EEG tensor y against a CLEAN REFERENCE x (both (N epochs, C channels, T samples)).

Seven components, each mapped to a score in (0,1] (1 = information fully preserved):
  spectral   - band-power consistency (delta..gamma)
  phase      - phase-locking preservation: (a) per-channel phase fidelity clean-vs-denoised,
                                          (b) inter-channel PLV matrices (phase synchrony)
  connect    - functional connectivity retention: amplitude-envelope-correlation matrices
  geometry   - covariance (Riemannian, affine-invariant) distance between spatial covariances
  erp        - ERP morphology: class-averaged ERP error + single-trial waveform correlation
  entropy    - permutation entropy + spectral entropy preservation
  task       - task discriminability retention (chance-normalised CV accuracy ratio)

Rule used everywhere:  relative error r  ->  score s = exp(-r / r0)     (r0 documented in SCALE)
Aggregation:           NIPI = prod_k s_k ** w_k   (weighted GEOMETRIC mean, sum w = 1)
   -> non-compensatory: a method that destroys phase cannot be "rescued" by preserving entropy.
All components are always reported next to the single number (never hide the breakdown).
"""
import math
import numpy as np
from scipy.signal import welch, hilbert, butter, sosfiltfilt
from scipy.linalg import eigh
from numpy.lib.stride_tricks import sliding_window_view
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

BANDS = dict(delta=(1, 4), theta=(4, 8), alpha=(8, 13), beta=(13, 30), gamma=(30, 45))
COMPONENTS = ['spectral', 'phase', 'connect', 'geometry', 'erp', 'entropy', 'task']
SCALE = dict(spectral=1.0, phase=1.0, connect=1.0, geometry=1.0, erp=1.0, entropy=0.1)  # r0 per component
EPS = 1e-12


def _s(r, r0=1.0):
    return float(np.exp(-r / r0))


def _band(x, lo, hi, fs):
    sos = butter(4, [lo, hi], btype='band', fs=fs, output='sos')
    return sosfiltfilt(sos, x, axis=-1)


def _trim(a, frac=0.1):
    k = int(a.shape[-1] * frac)
    return a[..., k:a.shape[-1] - k]


# ------------------------------------------------------------------ components
def spectral_consistency(x, y, fs):
    nper = min(256, x.shape[-1])
    f, Px = welch(x, fs, nperseg=nper, axis=-1)
    _, Py = welch(y, fs, nperseg=nper, axis=-1)
    d = []
    for lo, hi in BANDS.values():
        m = (f >= lo) & (f < hi)
        d.append(np.abs(np.log(Py[..., m].mean(-1) + EPS) - np.log(Px[..., m].mean(-1) + EPS)))
    return _s(np.mean(d), SCALE['spectral'])          # r = mean |ln power ratio|  (factor-2 error -> 0.69)


def phase_preservation(x, y, fs, bands=('theta', 'alpha', 'beta')):
    fid, plv = [], []
    for b in bands:
        lo, hi = BANDS[b]
        zx = _trim(hilbert(_band(x, lo, hi, fs), axis=-1)); zy = _trim(hilbert(_band(y, lo, hi, fs), axis=-1))
        px, py = zx / (np.abs(zx) + EPS), zy / (np.abs(zy) + EPS)         # unit phasors
        fid.append(np.abs((px * np.conj(py)).mean(-1)).mean())           # (a) phase fidelity, in [0,1]
        T = px.shape[-1]
        Cx = np.abs(np.einsum('nct,ndt->ncd', px, np.conj(px))) / T      # (b) PLV matrices (N,C,C)
        Cy = np.abs(np.einsum('nct,ndt->ncd', py, np.conj(py))) / T
        off = ~np.eye(Cx.shape[1], dtype=bool)
        r = np.linalg.norm((Cy - Cx)[:, off], axis=1) / (np.linalg.norm(Cx[:, off], axis=1) + EPS)
        plv.append(r.mean())
    return float(np.sqrt(np.mean(fid) * _s(np.mean(plv), SCALE['phase'])))


def connectivity_retention(x, y, fs, bands=('theta', 'alpha', 'beta')):
    rs = []
    for b in bands:
        lo, hi = BANDS[b]
        ex = _trim(np.abs(hilbert(_band(x, lo, hi, fs), axis=-1))); ey = _trim(np.abs(hilbert(_band(y, lo, hi, fs), axis=-1)))
        ex = (ex - ex.mean(-1, keepdims=True)) / (ex.std(-1, keepdims=True) + EPS)
        ey = (ey - ey.mean(-1, keepdims=True)) / (ey.std(-1, keepdims=True) + EPS)
        Ax = np.einsum('nct,ndt->ncd', ex, ex) / ex.shape[-1]; Ay = np.einsum('nct,ndt->ncd', ey, ey) / ey.shape[-1]
        off = ~np.eye(Ax.shape[1], dtype=bool)
        rs.append((np.linalg.norm((Ay - Ax)[:, off], axis=1) / (np.linalg.norm(Ax[:, off], axis=1) + EPS)).mean())
    return _s(np.mean(rs), SCALE['connect'])


def covariance_geometry(x, y, reg=1e-3):
    """Affine-invariant Riemannian distance  d = sqrt(sum ln^2 lambda_i),  lambda = gen. eigenvalues(Cy, Cx);
    normalised by sqrt(C) (RMS log-eigenvalue)."""
    C = x.shape[1]; ds = []
    for i in range(x.shape[0]):
        Cx = np.cov(x[i]); Cy = np.cov(y[i])
        Cx += reg * np.trace(Cx) / C * np.eye(C); Cy += reg * np.trace(Cy) / C * np.eye(C)
        lam = eigh(Cy, Cx, eigvals_only=True)
        ds.append(np.sqrt(np.sum(np.log(np.clip(lam, EPS, None)) ** 2) / C))
    return _s(np.mean(ds), SCALE['geometry'])


def erp_morphology(x, y, labels, fs, stim=1.0, win=(0.1, 0.6)):
    b = slice(0, int(fs * (stim - 0.1)))                                  # baseline = pre-stimulus
    w = slice(int(fs * (stim + win[0])), int(fs * (stim + win[1])))
    rs = []
    for c in np.unique(labels):
        ex, ey = x[labels == c].mean(0), y[labels == c].mean(0)
        ex = ex - ex[:, b].mean(1, keepdims=True); ey = ey - ey[:, b].mean(1, keepdims=True)
        rs.append(np.linalg.norm(ey[:, w] - ex[:, w]) / (np.linalg.norm(ex[:, w]) + EPS))
    s_avg = _s(np.mean(rs), SCALE['erp'])
    a, bb = x[..., w], y[..., w]
    a = a - a.mean(-1, keepdims=True); bb = bb - bb.mean(-1, keepdims=True)
    corr = (a * bb).sum(-1) / (np.linalg.norm(a, axis=-1) * np.linalg.norm(bb, axis=-1) + EPS)
    s_trial = float(np.clip(corr.mean(), 0, 1))
    return float(np.sqrt(s_avg * s_trial))


def _perm_entropy(x, m=3):
    w = sliding_window_view(x, m, axis=-1)
    codes = (np.argsort(w, axis=-1) * (m ** np.arange(m - 1, -1, -1))).sum(-1)
    p = np.stack([(codes == k).mean(-1) for k in np.unique(codes)])
    H = -(np.where(p > 0, p * np.log(p + EPS), 0)).sum(0)
    return H / np.log(math.factorial(m))


def _spec_entropy(x, fs):
    f, P = welch(x, fs, nperseg=min(256, x.shape[-1]), axis=-1)
    m = (f >= 1) & (f <= 45); P = P[..., m]; P = P / (P.sum(-1, keepdims=True) + EPS)
    return -(P * np.log(P + EPS)).sum(-1) / np.log(P.shape[-1])


def entropy_preservation(x, y, fs):
    rs = []
    for fn in (lambda a: _perm_entropy(a), lambda a: _spec_entropy(a, fs)):
        hx, hy = fn(x), fn(y)
        rs.append(np.mean(np.abs(hy - hx) / (np.abs(hx) + EPS)))
    return _s(np.mean(rs), SCALE['entropy'])        # 10 % relative entropy change -> e^-1


def _features(a, fs):
    f, P = welch(a, fs, nperseg=min(256, a.shape[-1]), axis=-1)
    fe = [np.log(P[..., (f >= lo) & (f < hi)].mean(-1) + EPS) for lo, hi in BANDS.values()]
    return np.concatenate(fe, axis=1)                                  # (N, C*bands)


def task_retention(x, y, labels, fs, seed=0):
    cv = StratifiedKFold(5, shuffle=True, random_state=seed)
    clf = make_pipeline(StandardScaler(), LogisticRegression(C=0.1, max_iter=2000))
    ax = cross_val_score(clf, _features(x, fs), labels, cv=cv).mean()
    ay = cross_val_score(clf, _features(y, fs), labels, cv=cv).mean()
    if len(np.unique(labels)) < 2: return float('nan'), float('nan'), float('nan')
    ch = 1.0 / len(np.unique(labels))
    if ax - ch < 0.1:                       # clean data not discriminable -> component undefined
        return float('nan'), ax, ay
    return float(np.clip((ay - ch) / (ax - ch), 0, 1)), ax, ay


# ------------------------------------------------------------------ aggregation
def nipi(x, y, labels, fs, weights=None, parts=COMPONENTS):
    """Returns dict with every component score + 'NIPI' (weighted geometric mean over defined components)."""
    out = {}
    if 'spectral' in parts: out['spectral'] = spectral_consistency(x, y, fs)
    if 'phase' in parts: out['phase'] = phase_preservation(x, y, fs)
    if 'connect' in parts: out['connect'] = connectivity_retention(x, y, fs)
    if 'geometry' in parts: out['geometry'] = covariance_geometry(x, y)
    if 'erp' in parts: out['erp'] = erp_morphology(x, y, labels, fs)
    if 'entropy' in parts: out['entropy'] = entropy_preservation(x, y, fs)
    if 'task' in parts:
        out['task'], out['acc_clean'], out['acc_den'] = task_retention(x, y, labels, fs)
    out['NIPI'] = aggregate(out, weights)
    return out


def aggregate(scores, weights=None):
    keys = [k for k in COMPONENTS if k in scores and not np.isnan(scores[k])]
    w = np.array([1.0 if weights is None else weights.get(k, 1.0) for k in keys]); w = w / w.sum()
    s = np.clip([scores[k] for k in keys], 1e-6, 1.0)
    return float(np.exp((w * np.log(s)).sum()))


def artifact_suppression(clean, noisy, den):
    """Complementary axis: ARR = 1 - ||den-clean||^2 / ||noisy-clean||^2 (clipped), RMSE, corr, SNR gain (dB)."""
    e0, e1 = ((noisy - clean) ** 2).sum(), ((den - clean) ** 2).sum()
    a, b = clean.reshape(len(clean), -1), den.reshape(len(den), -1)
    a = a - a.mean(1, keepdims=True); b = b - b.mean(1, keepdims=True)
    cc = ((a * b).sum(1) / (np.linalg.norm(a, axis=1) * np.linalg.norm(b, axis=1) + EPS)).mean()
    return dict(ARR=float(np.clip(1 - e1 / e0, 0, 1)), RMSE=float(np.sqrt(((den - clean) ** 2).mean())),
                CC=float(cc), SNR_gain_dB=float(10 * np.log10(e0 / (e1 + EPS))))


def joint_score(arr, nipi_value):
    """Single trade-off number = harmonic mean(ARR, NIPI): identity (ARR=0) and over-smoothing (NIPI~0) both score ~0."""
    return float(2 * arr * nipi_value / (arr + nipi_value + EPS))


def rank_stability(comp_table, n=2000, seed=0):
    """Robustness of method ranking to the weight choice. comp_table: {method: {component: score}}.
    Returns mean Kendall-tau between equal-weight ranking and ranking under random Dirichlet weights."""
    from scipy.stats import kendalltau
    names = list(comp_table); rng = np.random.default_rng(seed)
    keys = [k for k in COMPONENTS if all(k in comp_table[m] and not np.isnan(comp_table[m][k]) for m in names)]
    S = np.array([[comp_table[m][k] for k in keys] for m in names]).clip(1e-6, 1)
    base = (np.log(S)).mean(1); taus = []
    for _ in range(n):
        w = rng.dirichlet(np.ones(len(keys))); taus.append(kendalltau(base, np.log(S) @ w)[0])
    return float(np.nanmean(taus)), float(np.nanmin(taus))
