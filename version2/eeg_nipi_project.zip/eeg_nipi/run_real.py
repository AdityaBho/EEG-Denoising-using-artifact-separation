#!/usr/bin/env python
"""Run the full NIPD / NIPI study on REAL clean epochs (semi-synthetic artifacts added on top).

Examples
  # PhysioNet EEG Motor Movement/Imagery  (60 Hz mains, left/right imagery labels -> all 6 NIPI components)
  python run_real.py --dataset eegmmidb --path D:/data/eegmmidb --subjects S001 S002 S003 --line 60

  # Siena Scalp EEG (50 Hz mains, no markers -> NIPI uses S,P,C,H)
  python run_real.py --dataset siena --path D:/data/siena-scalp-eeg --line 50

  # Biosource / any EDF/BDF/FIF/SET file(s) with the 19 standard 10-20 electrodes
  python run_real.py --dataset edf --path rec1.edf rec2.edf --line 50

  # your own pre-epoched array (N,19,T) in microvolts, order = nipd.config.CH_NAMES
  python run_real.py --dataset npy --path epochs.npy --fs 256 --labels y.npy --cue 1.0
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nipd import data_real as dr
from nipd.pipeline import run_pipeline

ap = argparse.ArgumentParser()
ap.add_argument('--dataset', required=True, choices=['eegmmidb', 'siena', 'edf', 'npy'])
ap.add_argument('--path', nargs='+', required=True)
ap.add_argument('--subjects', nargs='+', default=['S001', 'S002', 'S003'])
ap.add_argument('--line', type=float, default=50.0)
ap.add_argument('--fs', type=float, default=None)
ap.add_argument('--labels', default=None)
ap.add_argument('--cue', type=float, default=None)
ap.add_argument('--lam', type=float, default=1.0)
ap.add_argument('--quick', action='store_true')
ap.add_argument('--out', default=None)
a = ap.parse_args()

if a.dataset == 'eegmmidb':
    X, y, fs, cue = dr.load_eegmmidb(a.path[0], tuple(a.subjects), line=a.line)
elif a.dataset == 'siena':
    X, y, fs, cue = dr.load_siena(a.path[0], line=a.line)
elif a.dataset == 'edf':
    X, y, fs, cue = dr.load_continuous(a.path, line=a.line)
else:
    X, y, fs, cue = dr.load_npy(a.path[0], a.fs, a.labels, a.cue)

# shuffle (keeps class balance in every split)
import numpy as np
idx = np.random.default_rng(0).permutation(len(X))
X, y = X[idx], (None if y is None else y[idx])
out = a.out or f'results/{a.dataset}'
run_pipeline(X, y, fs, cue, a.line, out, lam=a.lam, quick=a.quick, tag=f'({a.dataset})')
