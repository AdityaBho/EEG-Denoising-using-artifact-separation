#!/usr/bin/env python
"""One-command demo on synthetic EEG with known ground truth (no dataset download needed).

    python run_demo.py                 # full run  (~10-15 min on a laptop CPU)
    python run_demo.py --quick         # fast sanity run (~3 min)
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nipd.synthetic import make_synthetic_eeg
from nipd.pipeline import run_pipeline

ap = argparse.ArgumentParser()
ap.add_argument('--n_epochs', type=int, default=200)
ap.add_argument('--fs', type=float, default=256.0)
ap.add_argument('--line', type=float, default=50.0, help='mains frequency 50 (India/EU) or 60 (USA)')
ap.add_argument('--lam', type=float, default=1.0, help='weight of (1-NIPI) in the objective')
ap.add_argument('--out', default='results/synthetic')
ap.add_argument('--quick', action='store_true')
ap.add_argument('--seed', type=int, default=0)
a = ap.parse_args()

n = 100 if a.quick else a.n_epochs
d = make_synthetic_eeg(n_epochs=n, fs=a.fs, seed=a.seed)
run_pipeline(d['X'], d['y'], a.fs, d['cue_time'], a.line, a.out, lam=a.lam, quick=a.quick, tag='(synthetic EEG)', seed=a.seed)
