"""Train NIPD-Net on semi-synthetic contamination of clean EEG, with the NIPI feedback loop on lambda.
  python train.py --synthetic --epochs 30        (smoke test)
  python train.py --data data/clean_epochs.npz   (real clean epochs from data_real.py: arrays X (N,19,T), y (N,), fs)"""
import argparse, numpy as np, torch, pandas as pd
from eegnipi.simulate import make_clean
from eegnipi.artifacts import contaminate, GEN
from eegnipi.model import NIPDNet, Projector
from eegnipi.losses import total_loss, KEYS
from eegnipi.montage import laplacian
from eegnipi.nipi import nipi, artifact_suppression, joint_score
from eegnipi.baselines import CLASSICAL
from eegnipi.evaluate import evaluate_methods

p = argparse.ArgumentParser(); p.add_argument('--synthetic', action='store_true'); p.add_argument('--data')
p.add_argument('--epochs', type=int, default=30); p.add_argument('--bs', type=int, default=16); p.add_argument('--lr', type=float, default=1e-3)
a = p.parse_args(); dev = 'cuda' if torch.cuda.is_available() else 'cpu'; torch.manual_seed(0); rng = np.random.default_rng(0)
if a.synthetic: X, y = make_clean(n=400, fs=128, seed=0); fs = 128
else: d = np.load(a.data); X, y, fs = d['X'].astype(np.float32), d['y'], int(d['fs'])
n = len(X); tr, va, te = np.arange(0, int(.6 * n)), np.arange(int(.6 * n), int(.8 * n)), np.arange(int(.8 * n), n)
TYPES = ['eog', 'emg', 'motion', 'line']

def batch(idx, seed):                                     # fresh random contamination every call (data augmentation)
    r = np.random.default_rng(seed); kind = r.choice(TYPES + ['mixed']); snr = r.uniform(-5, 5)
    noisy, art, _ = contaminate(X[idx], kind, snr, fs, seed)
    t = np.zeros((len(idx), 4), np.float32)
    for k in (TYPES[:2] + ['line'] if kind == 'mixed' else [kind]): t[:, TYPES.index(k)] = 1
    return [torch.tensor(v, device=dev) for v in (noisy, X[idx], t)]

net, proj = NIPDNet().to(dev), Projector().to(dev); L = torch.tensor(laplacian(), dtype=torch.float32, device=dev)
opt = torch.optim.AdamW(list(net.parameters()) + list(proj.parameters()), lr=a.lr, weight_decay=1e-4)
lam = dict(rec=1.0, spec=0.5, phase=0.5, conn=0.5, cov=0.5, graph=0.1, info=0.1, type=0.1)
MAP = dict(spectral='spec', phase='phase', connect='conn', geometry='cov', task='info', erp='rec', entropy='spec')
best = -1
for ep in range(a.epochs):
    net.train(); perm = rng.permutation(tr); logs = []
    for i in range(0, len(perm) - a.bs + 1, a.bs):
        noisy, clean, t = batch(perm[i:i + a.bs], int(rng.integers(10**9)))
        loss, parts = total_loss(net(noisy), clean, t, proj, lam, fs, L); opt.zero_grad(); loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); logs.append(parts)
    # ---- validation + NIPI FEEDBACK LOOP (slide: "NIPI shows where information is lost; lambda is adjusted") ----
    net.eval(); noisy, art, _ = contaminate(X[va], 'mixed', 0, fs, 123)
    with torch.no_grad(): den = net(torch.tensor(noisy, device=dev))[0].cpu().numpy()
    r = nipi(X[va], den, y[va], fs); s = artifact_suppression(X[va], noisy, den); J = joint_score(s['ARR'], r['NIPI'])
    for comp, k in MAP.items():
        if comp in r and not np.isnan(r[comp]): lam[k] = float(np.clip(lam[k] * np.exp(0.2 * (1 - r[comp])), 0.05, 5.0))
    print(f"ep{ep:02d} loss={np.mean([l['rec'] for l in logs]):.3f} ARR={s['ARR']:.2f} NIPI={r['NIPI']:.3f} Joint={J:.3f} "
          + ' '.join(f"{k}={r[k]:.2f}" for k in ('spectral', 'phase', 'connect', 'geometry', 'erp', 'entropy', 'task')))
    if J > best: best = J; torch.save(net.state_dict(), 'outputs/best_nipdnet.pt')

# ---------------- final test: proposed vs baselines across SNR (same NIPI, same ground truth) ----------------
net.load_state_dict(torch.load('outputs/best_nipdnet.pt')); net.eval()
def proposed(noisy, refs, fs):
    with torch.no_grad(): return net(torch.tensor(noisy, device=dev))[0].cpu().numpy()
methods = {**CLASSICAL, 'Proposed_NIPDNet': proposed}; rows = []
for kind in ['eog', 'emg', 'motion', 'line', 'mixed']:
    for snr in [-5, 0, 5]:
        df, _ = evaluate_methods(X[te], y[te], methods, fs, kind, snr, verbose=False); rows.append(df)
res = pd.concat(rows); res.to_csv('outputs/final_comparison.csv', index=False)
print(res.groupby('method')[['ARR', 'CC', 'NIPI', 'Joint']].mean().round(3).sort_values('Joint', ascending=False))
