"""PHASE-1 DEMO (CPU, ~2-4 min): classical baselines vs NIPI on semi-synthetic EEG with known ground truth.
Shows WHY NIPI is needed: methods with similar ARR/RMSE can differ strongly in preserved neural information."""
import numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from eegnipi.simulate import make_clean
from eegnipi.baselines import CLASSICAL
from eegnipi.evaluate import evaluate_methods
from eegnipi.nipi import rank_stability, COMPONENTS
FS = 128; clean, y = make_clean(n=160, fs=FS, seed=0); out = 'outputs'
allr = []
for kind, snr in [('mixed', 0), ('eog', -3), ('emg', -3), ('line', 0)]:
    print(f'\n== {kind} @ {snr} dB'); df, comp = evaluate_methods(clean, y, CLASSICAL, FS, kind, snr); allr.append(df)
    if kind == 'mixed':
        main, comp_main = df, comp
res = pd.concat(allr); res.to_csv(f'{out}/phase1_results.csv', index=False)
print('\nRank stability of NIPI ranking under random weights (mean tau, min tau):', rank_stability(comp_main))
fig, ax = plt.subplots(1, 2, figsize=(13, 4.5))
m = main.set_index('method')
ax[0].scatter(m['ARR'], m['NIPI'], s=80)
for k, r in m.iterrows(): ax[0].annotate(k, (r['ARR'], r['NIPI']), textcoords='offset points', xytext=(5, 5))
ax[0].set_xlabel('Artifact removal ratio (ARR)'); ax[0].set_ylabel('NIPI'); ax[0].set_title('Artifact removal vs information preserved (mixed, 0 dB)')
ax[0].set_xlim(-.05, 1.05); ax[0].set_ylim(0, 1.05); ax[0].grid(alpha=.3)
im = ax[1].imshow(m[COMPONENTS].values, vmin=0, vmax=1, cmap='viridis', aspect='auto')
ax[1].set_xticks(range(len(COMPONENTS))); ax[1].set_xticklabels(COMPONENTS, rotation=45); ax[1].set_yticks(range(len(m))); ax[1].set_yticklabels(m.index)
for i in range(len(m)):
    for j, c in enumerate(COMPONENTS): ax[1].text(j, i, f"{m[c].iloc[i]:.2f}", ha='center', va='center', color='w', fontsize=8)
ax[1].set_title('NIPI components'); plt.colorbar(im, ax=ax[1]); plt.tight_layout(); plt.savefig(f'{out}/phase1_nipi_vs_arr.png', dpi=150)
print(main[['method','ARR','RMSE','CC','NIPI','Joint']].round(3).to_string(index=False))
